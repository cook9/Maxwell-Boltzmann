clear all
close all

D=1;
nn=10000;
length=2;
dx=length/(nn-1);
tau=dx;
xx=zeros(nn,1);
xx(1)=-1;
for i=2:nn
xx(i)=xx(i-1)+dx;
end

pos=zeros(nn,1);
pos(1)=1;
for i=2:nn
pos(i)=pos(i-1)+1;
end

DenL=1/1;
PreL=1/1;
VelL=0/1;

DenR=1/2;
PreR=1/2;
VelR=0/1;

Den=zeros(nn,1);
Pre=zeros(nn,1);
Vel=zeros(nn,1);

for i=1:nn/2
Den(i)=DenL;
Pre(i)=PreL;
Vel(i)=VelL;
end

for i=nn/2+1:nn
Den(i)=DenR;
Pre(i)=PreR;
Vel(i)=VelR;
end

Rs=1;
bb=0;
ga=7/5;
aa=(D*(1-ga)+2)/(ga-1);
Tem=Pre./(Rs*Den);
Ene=Vel.^2+(D+aa)*Rs*Tem;
AA=D+aa;

Q9=9;
mq9=(Q9-1)/2;
co=0;
xi9=zeros(Q9,1);
for a=2:Q9
if mod(a,2)==0
co=co+1;
xi9(a)= co*dx/tau;
else
xi9(a)=-co*dx/tau;
end
end

chi9=xi9*tau;
step9=chi9/dx;

w9=zeros(Q9,1);
w9(1:1)=  (576*dx^8 - 820*dx^6*tau^2 + 819*dx^4*tau^4 - 450*dx^2*tau^6 + 105*tau^8)/(576*dx^8);
w9(2:3)= -(- 192*dx^6*tau^2 + 244*dx^4*tau^4 - 145*dx^2*tau^6 + 35*tau^8)/(240*dx^8);
w9(4:5)=  (- 48*dx^6*tau^2 + 169*dx^4*tau^4 - 130*dx^2*tau^6 + 35*tau^8)/(480*dx^8);
w9(6:7)= -(- 64*dx^6*tau^2 + 252*dx^4*tau^4 - 315*dx^2*tau^6 + 105*tau^8)/(5040*dx^8);
w9(8:9)=  (- 12*dx^6*tau^2 + 49*dx^4*tau^4 - 70*dx^2*tau^6 + 35*tau^8)/(13440*dx^8);

max4=zeros(nn,Q9);
for i=1:nn
for a=1:Q9
max4(i,a) = w9(a)*Den(i)*(((xi9(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi9(a) + ((xi9(a)^4 - 6*xi9(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi9(a)^3 + 3*xi9(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

Q7=7;
mq7=(Q7-1)/2;
co=0;
xi7=zeros(Q7,1);
for a=2:Q7
if mod(a,2)==0
co=co+1;
xi7(a)= co*dx/tau;
else
xi7(a)=-co*dx/tau;
end
end

chi7=xi7*tau;
step7=chi7/dx;

w7=zeros(Q7,1);
w7(1:1) =  (36*dx^6 - 49*dx^4*tau^2 + 42*dx^2*tau^4 - 15*tau^6)/(36*dx^6);
w7(2:3) =  (12*dx^4*tau^2 - 13*dx^2*tau^4 + 5*tau^6)/(16*dx^6);
w7(4:5) = -(3*dx^4*tau^2 - 10*dx^2*tau^4 + 5*tau^6)/(40*dx^6);
w7(6:7) =  (4*dx^4*tau^2 - 15*dx^2*tau^4 + 15*tau^6)/(720*dx^6);

vel3=zeros(nn,Q7);
for i=1:nn
for a=1:Q7
vel3(i,a) = w7(a)*Den(i)*(Vel(i) + xi7(a)*(Vel(i)^2 + Rs*Tem(i)) + ((xi7(a)^2 - 1)*(2*Rs*Tem(i)*Vel(i) + Vel(i)*(Rs*Tem(i) - 1) + ...
Vel(i)^3))/2 - ((- xi7(a)^3 + 3*xi7(a))*(3*Rs*Tem(i)*(Rs*Tem(i) - 1) + 3*Rs*Tem(i)*Vel(i)^2 + Vel(i)^4 + 3*Vel(i)^2*(Rs*Tem(i) - 1)))/6);
end
end

Q5=5;
mq5=(Q5-1)/2;
co=0;
xi5=zeros(Q5,1);
for a=2:Q5
if mod(a,2)==0
co=co+1;
xi5(a)= co*dx/tau;
else
xi5(a)=-co*dx/tau;
end
end

chi5=xi5*tau;
step5=chi5/dx;

w5=zeros(Q5,1);
w5(1:1) =  (4*dx^4 - 5*dx^2*tau^2 + 3*tau^4)/(4*dx^4);
w5(2:3) = -(- 4*dx^2*tau^2 + 3*tau^4)/(6*dx^4);
w5(4:5) =  (- dx^2*tau^2 + 3*tau^4)/(24*dx^4);

ten2=zeros(nn,Q5);
for i=1:nn
for a=1:Q5
ten2(i,a) = w5(a)*(bb + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2 - ((xi5(a)^2 - 1)*(bb - Pre(i)*(Vel(i)^2 + 2*Rs*Tem(i) + Rs*Tem(i)*(aa + 1)) - Rs*Tem(i)*bb - Vel(i)^2*(Den(i)*Vel(i)^2 + 4*Pre(i) + ...
Pre(i)*(aa + 1)) + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2))/2 + Vel(i)*xi5(a)*(Den(i)*Vel(i)^2 + 2*Pre(i) + Pre(i)*(aa + 1)));
end
end

f0=max4;
f1=vel3;
f2=ten2;

nt=1500;
time=0;
dt=tau;

%%% TEMPORAL LOOP
for t=1:nt
time=time+dt;

%%% UPDATE DISTRIBUTIONS
f0_t1=zeros(nn,Q9);
for i=mq9+1:nn-mq9
for a=1:Q9
f0_t1(i,a)=f0(i-step9(a),a);
end
end

f1_t1=zeros(nn,Q7);
for i=mq7+1:nn-mq7
for a=1:Q7
f1_t1(i,a)=f1(i-step7(a),a);
end
end

f2_t1=zeros(nn,Q5);
for i=mq5+1:nn-mq5
for a=1:Q5
f2_t1(i,a)=f2(i-step5(a),a);
end
end

%%% APPLY BOUNDARY CONDITIONS
for i=1:mq9
for a=1:Q9
f0_t1(i,a)=max4(i,a);
end
end
for i=nn-mq9+1:nn
for a=1:Q9
f0_t1(i,a)=max4(i,a);
end
end

for i=1:mq7
for a=1:Q7
f1_t1(i,a)=vel3(i,a);
end
end
for i=nn-mq7+1:nn
for a=1:Q7
f1_t1(i,a)=vel3(i,a);
end
end

for i=1:mq5
for a=1:Q5
f2_t1(i,a)=ten2(i,a);
end
end
for i=nn-mq5+1:nn
for a=1:Q5
f2_t1(i,a)=ten2(i,a);
end
end

%%% UPDATE MOMENTS
sum0=zeros(nn,1);
sum1=zeros(nn,1);
sum2=zeros(nn,1);

for a=1:Q9
sum0(:)=sum0(:)+f0_t1(:,a);
end

for a=1:Q7
sum1(:)=sum1(:)+f1_t1(:,a);
end

for a=1:Q5
sum2(:)=sum2(:)+f2_t1(:,a);
end

Den=sum0;
Vel=sum1./sum0;
Ene=sum2./sum0;
Tem=(Ene-Vel.^2)./((D+aa)*Rs);
Pre=Den.*Rs.*Tem;

ss=(ga*Pre./Den).^(1/2);
Ma=Vel./ss;

%%% UPDATE GAUSSIANS
f0=zeros(nn,Q9);
for i=1:nn
for a=1:Q9
f0(i,a) = w9(a)*Den(i)*(((xi9(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi9(a) + ((xi9(a)^4 - 6*xi9(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi9(a)^3 + 3*xi9(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

f1=zeros(nn,Q7);
for i=1:nn
for a=1:Q7
f1(i,a) = w7(a)*Den(i)*(Vel(i) + xi7(a)*(Vel(i)^2 + Rs*Tem(i)) + ((xi7(a)^2 - 1)*(2*Rs*Tem(i)*Vel(i) + Vel(i)*(Rs*Tem(i) - 1) + ...
Vel(i)^3))/2 - ((- xi7(a)^3 + 3*xi7(a))*(3*Rs*Tem(i)*(Rs*Tem(i) - 1) + 3*Rs*Tem(i)*Vel(i)^2 + Vel(i)^4 + 3*Vel(i)^2*(Rs*Tem(i) - 1)))/6);
end
end

f2=zeros(nn,Q5);
for i=1:nn
for a=1:Q5
f2(i,a) = w5(a)*(bb + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2 - ((xi5(a)^2 - 1)*(bb - Pre(i)*(Vel(i)^2 + 2*Rs*Tem(i) + Rs*Tem(i)*(aa + 1)) - Rs*Tem(i)*bb - Vel(i)^2*(Den(i)*Vel(i)^2 + 4*Pre(i) + ...
Pre(i)*(aa + 1)) + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2))/2 + Vel(i)*xi5(a)*(Den(i)*Vel(i)^2 + 2*Pre(i) + Pre(i)*(aa + 1)));
end
end

end %time 

%%% PLOT RESULTS

data = analytic_sod(time);

figure
hold on
sz=20;
set(gcf,'Color','white')

subplot(2,2,1)
hold on
title('DENSITY')
xlabel('x (m)')
ylabel('\rho  kg/m^{3}')
%plot(xx,Den,'LineStyle','--','Color','black')
scatter(xx,Den,sz,'black','filled')
plot(data.x,data.rho,'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([DenR DenL])
axis on
grid on
hold off

subplot(2,2,2)
hold on
title('MOMENTUM')
xlabel('x (m)')
ylabel('\rhov  kg/(m^{2}s)')
%plot(xx,Den.*Vel,'LineStyle','--','Color','black')
scatter(xx,Den.*Vel,sz,'black','filled')
plot(data.x,(data.rho).*(data.u),'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([0 max(Den.*Vel)])
axis on
grid on
hold off

subplot(2,2,3)
hold on
title('TEMPERATURE')
xlabel('x (m)')
ylabel('T  K')
%plot(xx,Tem,'LineStyle','--','Color','black')
scatter(xx,Tem,sz,'black','filled')
plot(data.x,(data.P)./(Rs*data.rho),'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([min(Tem) max((data.P)./(Rs*data.rho))])
axis on
grid on
hold off

subplot(2,2,4)
hold on
title('PRESSURE')
xlabel('x (m)')
ylabel('P  Pa')
%plot(xx,Pre,'LineStyle','--','Color','black')
scatter(xx,Pre,sz,'black','filled')
plot(data.x,data.P,'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([PreR PreL])
axis on
grid on
hold off

hold off