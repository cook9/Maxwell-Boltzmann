clear all
close all

D=1;

%%% SPATIAL GRID
nn=10000;
ne=nn-1;
length=2;
dx=length/ne;
xx=zeros(nn,1);
xx(1)=-1;
for i=2:nn
xx(i)=xx(i-1)+dx;
end

pos=zeros(nn,1);
pos(1)=1;
for i=2:nn
pos(i)=pos(i-1)+1;
end

%%% INITIAL CONDITIONS
DenL=1/1;
PreL=1/1;
VelL=0/1;

DenR=1/2;
PreR=1/2;
VelR=0/1;

Den=zeros(nn,1);
Pre=zeros(nn,1);
Vel=zeros(nn,1);

for i=1:nn/2
Den(i)=DenL;
Pre(i)=PreL;
Vel(i)=VelL;
end

for i=nn/2+1:nn
Den(i)=DenR;
Pre(i)=PreR;
Vel(i)=VelR;
end

Rs=1;
ga=7/5;
aa=(D*(1-ga)+2)/(ga-1);
Tem=Pre./(Rs*Den);
Ene=Vel.^2+(D+aa)*Rs*Tem;

%%% LATTICE & WEIGHTS
Q=9;
mq=(Q-1)/2;
tau=dx;

co=0;
xi=zeros(Q,1);
for a=2:Q
if mod(a,2)==0
co=co+1;
xi(a)=co*dx/tau;
else
xi(a)=-co*dx/tau;
end
end

chi=xi*tau;
step=chi/dx;

weight=zeros(Q,1);
weight(1:1)=  (576*dx^8 - 820*dx^6*tau^2 + 819*dx^4*tau^4 - 450*dx^2*tau^6 + 105*tau^8)/(576*dx^8);
weight(2:3)= -(- 192*dx^6*tau^2 + 244*dx^4*tau^4 - 145*dx^2*tau^6 + 35*tau^8)/(240*dx^8);
weight(4:5)=  (- 48*dx^6*tau^2 + 169*dx^4*tau^4 - 130*dx^2*tau^6 + 35*tau^8)/(480*dx^8);
weight(6:7)= -(- 64*dx^6*tau^2 + 252*dx^4*tau^4 - 315*dx^2*tau^6 + 105*tau^8)/(5040*dx^8);
weight(8:9)=  (- 12*dx^6*tau^2 + 49*dx^4*tau^4 - 70*dx^2*tau^6 + 35*tau^8)/(13440*dx^8);

%%% INITIAL DISCRETE MAXWELLIAN
maxw4=zeros(nn,Q);
for i=1:nn
for a=1:Q
maxw4(i,a)=weight(a)*Den(i)*(((xi(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi(a) + ((xi(a)^4 - 6*xi(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi(a)^3 + 3*xi(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

Qe=5;
mqe=(Qe-1)/2;

co=0;
xie=zeros(Qe,1);
for a=2:Qe
if mod(a,2)==0
co=co+1;
xie(a)=co*dx/tau;
else
xie(a)=-co*dx/tau;
end
end

chie=xie*tau;
stepe=chie/dx;

we=zeros(Qe,1);
we(1:1) =  (4*dx^4 - 5*dx^2*tau^2 + 3*tau^4)/(4*dx^4);
we(2:3) = -(- 4*dx^2*tau^2 + 3*tau^4)/(6*dx^4);
we(4:5) =  (- dx^2*tau^2 + 3*tau^4)/(24*dx^4);

te2=zeros(nn,Qe);
for i=1:nn
for a=1:Qe
te2(i,a)=we(a)*(0 + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2 - ((xie(a)^2 - 1)*(0 - Pre(i)*(Vel(i)^2 + 2*Rs*Tem(i) + Rs*Tem(i)*(aa + 1)) - Rs*Tem(i)*0 - Vel(i)^2*(Den(i)*Vel(i)^2 + 4*Pre(i) + Pre(i)*(aa + 1)) + ...
Pre(i)*(aa + 1) + Den(i)*Vel(i)^2))/2 + Vel(i)*xie(a)*(Den(i)*Vel(i)^2 + 2*Pre(i) + Pre(i)*(aa + 1)));
end
end

f0=maxw4;
f1=te2;

%%% TEMPORAL LOOP

nt=1500;
time=0;
dt=tau;

for t=1:nt
time=time+dt;

%%% UPDATE DISTRIBUTION 
f0_t1=zeros(nn,Q);
for i=mq+1:nn-mq
for a=1:Q
f0_t1(i,a)=f0(i-step(a),a);
end
end

f1_t1=zeros(nn,Qe);
for i=mqe+1:nn-mqe
for a=1:Qe
f1_t1(i,a)=f1(i-stepe(a),a);
end
end

%%% APPLY BOUNDARY CONDITIONS 
for i=1:mq
for a=1:Q
f0_t1(i,a)=maxw4(i,a);
end
end
for i=nn-mq+1:nn
for a=1:Q
f0_t1(i,a)=maxw4(i,a);
end
end

for i=1:mqe
for a=1:Qe
f1_t1(i,a)=te2(i,a);
end
end
for i=nn-mqe+1:nn
for a=1:Qe
f1_t1(i,a)=te2(i,a);
end
end

%%% UPDATE MOMENTS
sum0=zeros(nn,1);
sum1=zeros(nn,1);
for a=1:Q
sum0(:)=sum0(:)+f0_t1(:,a);
sum1(:)=sum1(:)+f0_t1(:,a)*xi(a);
end

sum2=zeros(nn,1);
for a=1:Qe
sum2(:)=sum2(:)+f1_t1(:,a);
end

Den=sum0;
Vel=sum1./sum0;
Ene=sum2./sum0;
Tem=(Ene-Vel.^2)./((D+aa)*Rs);
Pre=Den.*Rs.*Tem;

%%% UPDATE MAXWELLIAN  
f0=zeros(nn,Q);
for i=1:nn
for a=1:Q
f0(i,a) = weight(a)*Den(i)*(((xi(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi(a) + ((xi(a)^4 - 6*xi(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi(a)^3 + 3*xi(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

f1=zeros(nn,Qe);
for i=1:nn
for a=1:Qe
f1(i,a)=we(a)*(0 + Pre(i)*(aa + 1) + Den(i)*Vel(i)^2 - ((xie(a)^2 - 1)*(0 - Pre(i)*(Vel(i)^2 + 2*Rs*Tem(i) + Rs*Tem(i)*(aa + 1)) - Rs*Tem(i)*0 - Vel(i)^2*(Den(i)*Vel(i)^2 + 4*Pre(i) + Pre(i)*(aa + 1)) + ...
Pre(i)*(aa + 1) + Den(i)*Vel(i)^2))/2 + Vel(i)*xie(a)*(Den(i)*Vel(i)^2 + 2*Pre(i) + Pre(i)*(aa + 1)));
end
end

end %time 

%%% PLOT RESULTS

data = analytic_sod(time);

figure
hold on
sz=20;
set(gcf,'Color','white')

subplot(2,2,1)
hold on
title('DENSITY')
xlabel('x (m)')
ylabel('\rho  kg/m^{3}')
%plot(xx,Den,'LineStyle','--','Color','black')
scatter(xx,Den,sz,'black','filled')
plot(data.x,data.rho,'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([DenR DenL])
axis on
grid on
hold off

subplot(2,2,2)
hold on
title('MOMENTUM')
xlabel('x (m)')
ylabel('\rhov  kg/(m^{2}s)')
%plot(xx,Den.*Vel,'LineStyle','--','Color','black')
scatter(xx,Den.*Vel,sz,'black','filled')
plot(data.x,(data.rho).*(data.u),'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([0 max(Den.*Vel)])
axis on
grid on
hold off

subplot(2,2,3)
hold on
title('TEMPERATURE')
xlabel('x (m)')
ylabel('T  K')
%plot(xx,Tem,'LineStyle','--','Color','black')
scatter(xx,Tem,sz,'black','filled')
plot(data.x,(data.P)./(Rs*data.rho),'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([min(Tem) max((data.P)./(Rs*data.rho))])
axis on
grid on
hold off

subplot(2,2,4)
hold on
title('PRESSURE')
xlabel('x (m)')
ylabel('P  Pa')
%plot(xx,Pre,'LineStyle','--','Color','black')
scatter(xx,Pre,sz,'black','filled')
plot(data.x,data.P,'LineStyle','--','Color','red')
xlim([xx(1) xx(nn)])
ylim([PreR PreL])
axis on
grid on
hold off

hold off