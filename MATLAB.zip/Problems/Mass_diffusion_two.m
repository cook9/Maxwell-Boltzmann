clear all
close all

d=1;
D=2;
q=9;
Q=q^D;
mq=(q-1)/2;

%%% SPATIAL GRID
nx=100;
length=2;
dx=length/(nx-1);
xvec=zeros(nx,1);
for i=2:nx
xvec(i)=xvec(i-1)+dx;
end

ny=nx;
height=length;
dy=height/(ny-1);
yvec=zeros(ny,1);
for i=2:ny
yvec(i)=yvec(i-1)+dy;
end

nn=nx;
NN=nx*ny;

[xmat,ymat]=meshgrid(xvec,yvec);
ymat=flip(ymat,1);

posxvec=zeros(nx,1);
posxvec(1)=1;
for i=2:nx
posxvec(i)=posxvec(i-1)+1;
end

posyvec=zeros(ny,1);
posyvec(1)=1;
for i=2:ny
posyvec(i)=posyvec(i-1)+1;
end

[posxmat,posymat]=meshgrid(posxvec,posyvec);
posymat=flip(posymat,1);

%%% INITIAL CONDITIONS

DenO=1/1;
PreO=1/1;
VelO=0/1;

DenI=1/100;
PreI=1/100;
VelI=0/1;

Den=zeros(nx,ny);
Pre=zeros(nx,ny);
Velx=zeros(nx,ny);
Vely=zeros(nx,ny);

for i=1:nx/4
for j=1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=1:nx
for j=1:ny/4
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=3*nx/4+1:nx
for j=1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=1:nx
for j=3*ny/4+1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=nx/4+1:3*nx/4
for j=ny/4+1:3*ny/4
Den(i,j)=DenI;
Pre(i,j)=PreI;
end
end

Rs=1;
aa=0;
Tem=Pre./(Rs*Den);
Ene=Velx.^2+Vely.^2+(D+aa)*Rs*Tem;

%%% LATTICE & WEIGHTS
dd=dx;
tau=dd;
co=0;
xix=zeros(q,d);
xiy=zeros(q,d);
for a=2:q
if mod(a,2)==0
co=co+1;
xix(a)=co*dd/tau;
xiy(a)=co*dd/tau;
else
xix(a)=-co*dd/tau;
xiy(a)=-co*dd/tau;
end
end

chix=xix*tau;
stepx=chix/dx;

chiy=xiy*tau;
stepy=chiy/dy;

sx=stepx;
sy=stepy;

count=0;
xi=zeros(Q,D);
for a=1:q
for b=1:q
count=count+1;
xi(count,1)=xix(a);
xi(count,2)=xiy(b);
end
end

chi=xi*tau;
step=chi/dd;

% figure
% hold on
% for a=1:Q
% quiver(0,0,xi(a,1),xi(a,2),0,'Color','black')
% end
% xlim([-mq mq])
% ylim([-mq mq])
% grid on
% axis on
% hold off

w=zeros(q,1);
w(1:1)=  (576*dx^8 - 820*dx^6*tau^2 + 819*dx^4*tau^4 - 450*dx^2*tau^6 + 105*tau^8)/(576*dx^8);
w(2:3)= -(- 192*dx^6*tau^2 + 244*dx^4*tau^4 - 145*dx^2*tau^6 + 35*tau^8)/(240*dx^8);
w(4:5)=  (- 48*dx^6*tau^2 + 169*dx^4*tau^4 - 130*dx^2*tau^6 + 35*tau^8)/(480*dx^8);
w(6:7)= -(- 64*dx^6*tau^2 + 252*dx^4*tau^4 - 315*dx^2*tau^6 + 105*tau^8)/(5040*dx^8);
w(8:9)=  (- 12*dx^6*tau^2 + 49*dx^4*tau^4 - 70*dx^2*tau^6 + 35*tau^8)/(13440*dx^8);

weight=zeros(Q,1);
count=0;
for a=1:q
for b=1:q
count=count+1;
weight(count)=w(a)*w(b);
end
end

%%% INITIALIZE DISCRETE MAXWELLIAN 
maxw4=zeros(nx,ny,q,q);
for i=1:nx
for j=1:ny
for a=1:q
for b=1:q
maxw4(i,j,a,b) = w(a)*w(b)*Den(i,j)*(...
	((xix(a)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ((xiy(b)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + Velx(i,j)*xix(a) + Vely(i,j)*xiy(b) + ...
	((xix(a)^4 - 6*xix(a)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Velx(i,j)^2 - 6*Rs*Tem(i,j) + Velx(i,j)^4 - 6*Velx(i,j)^2 + 3))/24 + ...
	((xiy(b)^4 - 6*xiy(b)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Vely(i,j)^2 - 6*Rs*Tem(i,j) + Vely(i,j)^4 - 6*Vely(i,j)^2 + 3))/24 + ...
	(Velx(i,j)*xix(a)*(xiy(b)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + (Vely(i,j)*xiy(b)*(xix(a)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ...
	Velx(i,j)*Vely(i,j)*xix(a)*xiy(b) + (Velx(i,j)*xix(a)*(xix(a)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + (Vely(i,j)*xiy(b)*(xiy(b)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	((xix(a)^2 - 1)*(xiy(b)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/4 + (Velx(i,j)*Vely(i,j)*xix(a)*xiy(b)*(xix(a)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	(Velx(i,j)*Vely(i,j)*xix(a)*xiy(b)*(xiy(b)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + 1);
end
end
end
end

f0=maxw4;

%%% TEMPORAL LOOP
time=0;
nt=100;
dt=tau;
for t=1:nt
time=time+dt;

%%% UPDATE DISTRIBUTION 

f0_t1=zeros(nx,ny,q,q);
for i=mq+1:nx-mq
for j=mq+1:ny-mq
for a=1:q
for b=1:q
if a==1 && b==1
f0_t1(i,j,a,b)=f0(i,j,a,b);
else
f0_t1(i,j,a,b)=f0(i,j,a,b)+Rs*Tem(i,j)/(xix(a)^2+xiy(b)^2)*(f0(i+sx(a),j+sy(b),a,b)-2*f0(i,j,a,b)+f0(i-sx(a),j-sy(b),a,b));
end
end
end
end
end

%%% APPLY BOUNDARY CONDITIONS 

% LEFT SECTION
for i=mq+1:nx-mq
for j=1:mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% RIGHT SECTION
for i=mq+1:nx-mq
for j=ny-mq+1:ny
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% BOTTOM SECTION
for i=nx-mq+1:nx
for j=mq+1:ny-mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% TOP SECTION
for i=1:mq
for j=mq+1:ny-mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% TOP LEFT CORNER
for i=1:mq
for j=1:mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% BOTTOM LEFT CORNER
for i=nx-mq+1:nx
for j=1:mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% TOP RIGHT CORNER
for i=1:mq
for j=ny-mq+1:ny
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% BOTTOM RIGHT CORNER
for i=nx-mq+1:nx
for j=ny-mq+1:ny
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

% MIDDLE SECTION
matrix=ones(nx,ny,q,q);
for i=nx/2-mq:nx/2+mq
for j=ny/2-mq:ny/2+mq
for a=1:q
for b=1:q
f0_t1(i,j,a,b)=maxw4(i,j,a,b);
end
end
end
end

%%% UPDATE MOMENTS

sum0=zeros(nx,ny);
for a=1:q
for b=1:q
sum0(:,:)=sum0(:,:)+f0_t1(:,:,a,b);
end
end

Den=sum0;

%%% UPDATE DISCRETE MAXWELLIAN 

f0=zeros(nx,ny,q,q);
for i=1:nx
for j=1:ny
for a=1:q
for b=1:q
f0(i,j,a,b) = w(a)*w(b)*Den(i,j)*(...
	((xix(a)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ((xiy(b)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + Velx(i,j)*xix(a) + Vely(i,j)*xiy(b) + ...
	((xix(a)^4 - 6*xix(a)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Velx(i,j)^2 - 6*Rs*Tem(i,j) + Velx(i,j)^4 - 6*Velx(i,j)^2 + 3))/24 + ...
	((xiy(b)^4 - 6*xiy(b)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Vely(i,j)^2 - 6*Rs*Tem(i,j) + Vely(i,j)^4 - 6*Vely(i,j)^2 + 3))/24 + ...
	(Velx(i,j)*xix(a)*(xiy(b)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + (Vely(i,j)*xiy(b)*(xix(a)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ...
	Velx(i,j)*Vely(i,j)*xix(a)*xiy(b) + (Velx(i,j)*xix(a)*(xix(a)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + (Vely(i,j)*xiy(b)*(xiy(b)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	((xix(a)^2 - 1)*(xiy(b)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/4 + (Velx(i,j)*Vely(i,j)*xix(a)*xiy(b)*(xix(a)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	(Velx(i,j)*Vely(i,j)*xix(a)*xiy(b)*(xiy(b)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + 1);
end
end
end
end

end %time

%%% PLOT RESULTS
no=10;
sz=20;
figure
hold on
set(gcf,'color','white')

subplot(1,2,1)
hold on
title('DENSITY')
xlabel('x (m)')
ylabel('y (m)')
contour(xmat,ymat,Den,no,'black')
xlim([0 length])
ylim([0 height])
axis equal
grid on
hold off

% title('DENSITY')
% xlabel('x (m)')
% ylabel('\rho  kg/m^{3}')
% plot(xmat(nn/2,:),Den(nn/2,:),'LineStyle','--','Color','black')
% scatter(xmat(nn/2,:),Den(nn/2,:),sz,'black','filled')
% xlim([0 length])
% ylim([DenI DenO])
% grid on

hold off