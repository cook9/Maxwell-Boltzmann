clear all
close all

D=1;

%%% SPATIAL GRID
nn=100;
ne=nn-1;
length=2;
dx=length/ne;
xx=zeros(nn,1);
xx(1)=-1;
for i=2:nn
xx(i)=xx(i-1)+dx;
end

pos=zeros(nn,1);
pos(1)=1;
for i=2:nn
pos(i)=pos(i-1)+1;
end

%%% INITIAL CONDITIONS
DenL=1/1;
PreL=1/1;
VelL=0/1;

DenR=1/100;
PreR=1/100;
VelR=0/1;

Den=zeros(nn,1);
Pre=zeros(nn,1);
Vel=zeros(nn,1);

for i=1:nn/2
Den(i)=DenL;
Pre(i)=PreL;
Vel(i)=VelL;
end

for i=nn/2+1:nn
Den(i)=DenR;
Pre(i)=PreR;
Vel(i)=VelR;
end

Rs=1;
aa=0;
Tem=Pre./(Rs*Den);
Ene=Vel.^2+(D+aa)*Rs*Tem;

%%% LATTICE & WEIGHTS
Q=9;
mq=(Q-1)/2;
tau=dx;

co=0;
xi=zeros(Q,1);
for a=2:Q
if mod(a,2)==0
co=co+1;
xi(a)= co*dx/tau;
else
xi(a)=-co*dx/tau;
end
end

chi=xi*tau;
step=chi/dx;

weight=zeros(Q,1);
weight(1:1)=  (576*dx^8 - 820*dx^6*tau^2 + 819*dx^4*tau^4 - 450*dx^2*tau^6 + 105*tau^8)/(576*dx^8);
weight(2:3)= -(- 192*dx^6*tau^2 + 244*dx^4*tau^4 - 145*dx^2*tau^6 + 35*tau^8)/(240*dx^8);
weight(4:5)=  (- 48*dx^6*tau^2 + 169*dx^4*tau^4 - 130*dx^2*tau^6 + 35*tau^8)/(480*dx^8);
weight(6:7)= -(- 64*dx^6*tau^2 + 252*dx^4*tau^4 - 315*dx^2*tau^6 + 105*tau^8)/(5040*dx^8);
weight(8:9)=  (- 12*dx^6*tau^2 + 49*dx^4*tau^4 - 70*dx^2*tau^6 + 35*tau^8)/(13440*dx^8);

%%% INITIAL DISCRETE MAXWELLIAN
maxw4=zeros(nn,Q);
for i=1:nn
for a=1:Q
maxw4(i,a)=weight(a)*Den(i)*(((xi(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi(a) + ((xi(a)^4 - 6*xi(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi(a)^3 + 3*xi(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

f0=maxw4;

%%% TEMPORAL LOOP
nt=100;
time=0;
dt=tau;
for t=1:nt
time=time+dt;

% d1=zeros(nn,Q);
% for i=mq+1:nn-mq
% for a=2:Q
% d1(i,a)=(f0(i,a)-f0(i-step(a),a))/chi(a);
% end
% end
% 
% d2=zeros(nn,Q);
% for i=mq+1:nn-mq
% for a=2:Q
% d2(i,a)=(d1(i+step(a),a)-d1(i,a))/chi(a);
% end
% end

%%% UPDATE DISTRIBUTION 
f0_t1=zeros(nn,Q);
for i=mq+1:nn-mq
for a=2:Q
f0_t1(i,a)=f0(i,a)+Rs*Tem(i)/(xi(a)^2)*(f0(i+step(a),a)-2*f0(i,a)+f0(i-step(a),a));
% f0_t1(i,a)=f0(i,a)+Rs*Tem(i)*tau^2*d2(i,a);
end
end

for i=mq+1:nn-mq
for a=1:1
f0_t1(i,a)=f0(i,a);
end
end

%%% APPLY BOUNDARY CONDITIONS 
for i=1:mq
for a=1:Q
f0_t1(i,a)=maxw4(i,a);
end
end
for i=nn-mq+1:nn
for a=1:Q
f0_t1(i,a)=maxw4(i,a);
end
end

%%% UPDATE MOMENTS
sum0=zeros(nn,1);
smxx=zeros(nn,1);
for a=1:Q
sum0(:)=sum0(:)+f0_t1(:,a);
end

Den=sum0;

%%% UPDATE MAXWELLIAN  
f0=zeros(nn,Q);
for i=1:nn
for a=1:Q
f0(i,a) = weight(a)*Den(i)*(((xi(a)^2 - 1)*(Vel(i)^2 + Rs*Tem(i) - 1))/2 + Vel(i)*xi(a) + ((xi(a)^4 - 6*xi(a)^2 + 3)*(3*(Rs*Tem(i) - 1)^2 + ...
Vel(i)^4 + 6*Vel(i)^2*(Rs*Tem(i) - 1)))/24 - ((- xi(a)^3 + 3*xi(a))*(3*Vel(i)*(Rs*Tem(i) - 1) + Vel(i)^3))/6 + 1);
end
end

end %time 

%%% PLOT RESULTS
sz=20;
figure
hold on
set(gcf,'Color','white')

subplot(2,2,1)
hold on
title('DENSITY')
xlabel('x (m)')
ylabel('\rho  kg/m^{3}')
plot(xx,Den,'LineStyle','--','Color','black')
scatter(xx,Den,sz,'black','filled')
xlim([xx(1) xx(nn)])
ylim([DenR DenL])
axis on
grid on
hold off

hold off