clear all
close all

d=1;
D=2;
q=9;
Q=q^D;
mq=(q-1)/2;

%%% SPATIAL GRID
nx=1000;
length=2;
dx=length/(nx-1);
xvec=zeros(nx,1);
for i=2:nx
xvec(i)=xvec(i-1)+dx;
end

ny=nx;
height=length;
dy=height/(ny-1);
yvec=zeros(ny,1);
for i=2:ny
yvec(i)=yvec(i-1)+dy;
end

[xmat,ymat]=meshgrid(xvec,yvec);
ymat=flip(ymat,1);

posxvec=zeros(nx,1);
posxvec(1)=1;
for i=2:nx
posxvec(i)=posxvec(i-1)+1;
end

posyvec=zeros(ny,1);
posyvec(1)=1;
for i=2:ny
posyvec(i)=posyvec(i-1)+1;
end

[posxmat,posymat]=meshgrid(posxvec,posyvec);
posymat=flip(posymat,1);

%%% INITIAL CONDITIONS

DenO=1/1;
PreO=1/1;
VelO=0/1;

DenI=1/2;
PreI=1/2;
VelI=0/1;

Den=zeros(nx,ny);
Pre=zeros(nx,ny);
Velx=zeros(nx,ny);
Vely=zeros(nx,ny);

for i=1:nx/4
for j=1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=1:nx
for j=1:ny/4
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=3*nx/4+1:nx
for j=1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=1:nx
for j=3*ny/4+1:ny
Den(i,j)=DenO;
Pre(i,j)=PreO;
end
end

for i=nx/4+1:3*nx/4
for j=ny/4+1:3*ny/4
Den(i,j)=DenI;
Pre(i,j)=PreI;
end
end

Rs=1;
ga=7/5;
aa=(D*(1-ga)+2)/(ga-1);
Tem=Pre./(Rs*Den);
Ene=Velx.^2+Vely.^2+(D+aa)*Rs*Tem;

%%% LATTICE & WEIGHTS
dd=dx;
tau=dd;
co=0;
xix=zeros(q,d);
xiy=zeros(q,d);
for a=2:q
if mod(a,2)==0
co=co+1;
xix(a)=co*dd/tau;
xiy(a)=co*dd/tau;
else
xix(a)=-co*dd/tau;
xiy(a)=-co*dd/tau;
end
end

count=0;
xi=zeros(Q,D);
for a=1:q
for b=1:q
count=count+1;
xi(count,1)=xix(a);
xi(count,2)=xiy(b);
end
end

chi=xi*tau;
step=chi/dd;

% figure
% hold on
% for a=1:Q
% quiver(0,0,xi(a,1),xi(a,2),0,'Color','black')
% end
% xlim([-mq mq])
% ylim([-mq mq])
% grid on
% axis on
% hold off

w=zeros(q,1);
w(1:1)=  (576*dx^8 - 820*dx^6*tau^2 + 819*dx^4*tau^4 - 450*dx^2*tau^6 + 105*tau^8)/(576*dx^8);
w(2:3)= -(- 192*dx^6*tau^2 + 244*dx^4*tau^4 - 145*dx^2*tau^6 + 35*tau^8)/(240*dx^8);
w(4:5)=  (- 48*dx^6*tau^2 + 169*dx^4*tau^4 - 130*dx^2*tau^6 + 35*tau^8)/(480*dx^8);
w(6:7)= -(- 64*dx^6*tau^2 + 252*dx^4*tau^4 - 315*dx^2*tau^6 + 105*tau^8)/(5040*dx^8);
w(8:9)=  (- 12*dx^6*tau^2 + 49*dx^4*tau^4 - 70*dx^2*tau^6 + 35*tau^8)/(13440*dx^8);

weight=zeros(Q,1);
count=0;
for a=1:q
for b=1:q
count=count+1;
weight(count)=w(a)*w(b);
end
end

%%% INITIALIZE DISCRETE MAXWELLIAN 
maxw4=zeros(nx,ny,Q);
for i=1:nx
for j=1:ny
for a=1:Q
maxw4(i,j,a) = weight(a)*Den(i,j)*(...
	((xi(a,1)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ((xi(a,2)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + Velx(i,j)*xi(a,1) + Vely(i,j)*xi(a,2) + ...
	((xi(a,1)^4 - 6*xi(a,1)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Velx(i,j)^2 - 6*Rs*Tem(i,j) + Velx(i,j)^4 - 6*Velx(i,j)^2 + 3))/24 + ...
	((xi(a,2)^4 - 6*xi(a,2)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Vely(i,j)^2 - 6*Rs*Tem(i,j) + Vely(i,j)^4 - 6*Vely(i,j)^2 + 3))/24 + ...
	(Velx(i,j)*xi(a,1)*(xi(a,2)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + (Vely(i,j)*xi(a,2)*(xi(a,1)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ...
	Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2) + (Velx(i,j)*xi(a,1)*(xi(a,1)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + (Vely(i,j)*xi(a,2)*(xi(a,2)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	((xi(a,1)^2 - 1)*(xi(a,2)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/4 + (Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2)*(xi(a,1)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	(Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2)*(xi(a,2)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + 1);
end
end
end

qe=5;
mqe=(qe-1)/2;
co=0;
xixe=zeros(qe,d);
xiye=zeros(qe,d);
for a=2:qe
if mod(a,2)==0
co=co+1;
xixe(a)=co*dd/tau;
xiye(a)=co*dd/tau;
else
xixe(a)=-co*dd/tau;
xiye(a)=-co*dd/tau;
end
end

Qe=qe^D;
count=0;
xie=zeros(Qe,D);
for a=1:qe
for b=1:qe
count=count+1;
xie(count,1)=xixe(a);
xie(count,2)=xiye(b);
end
end

chie=xie*tau;
stepe=chie/dd;

weighte=zeros(qe,1);
weighte(1:1) =  (4*dx^4 - 5*dx^2*tau^2 + 3*tau^4)/(4*dx^4);
weighte(2:3) = -(- 4*dx^2*tau^2 + 3*tau^4)/(6*dx^4);
weighte(4:5) =  (- dx^2*tau^2 + 3*tau^4)/(24*dx^4);

we=zeros(Qe,1);
count=0;
for a=1:qe
for b=1:qe
count=count+1;
we(count)=weighte(a)*weighte(b);
end
end

te2=zeros(nx,ny,Qe);
for i=1:nx
for j=1:ny
for a=1:Qe
te2(i,j,a)=we(a)*(0 - ((xie(a,1)^2 - 1)*(0 - Velx(i,j)^2*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + Pre(i,j)*(aa + 2)) - Rs*Tem(i,j)*0 + Pre(i,j)*(aa + 2) + Den(i,j)*Velx(i,j)^2 + ...
Den(i,j)*Vely(i,j)^2 - Pre(i,j)*(Velx(i,j)^2 + Vely(i,j)^2 + 2*Rs*Tem(i,j) + Rs*Tem(i,j)*(aa + 2))))/2 - ((xie(a,2)^2 - 1)*(0 - Vely(i,j)^2*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + ...
Pre(i,j)*(aa + 2)) - Rs*Tem(i,j)*0 + Pre(i,j)*(aa + 2) + Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 - Pre(i,j)*(Velx(i,j)^2 + Vely(i,j)^2 + 2*Rs*Tem(i,j) + Rs*Tem(i,j)*(aa + 2))))/2 + Pre(i,j)*(aa + 2) + ...
Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + Velx(i,j)*xie(a,1)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 2*Pre(i,j) + Pre(i,j)*(aa + 2)) + Vely(i,j)*xie(a,2)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + ...
2*Pre(i,j) + Pre(i,j)*(aa + 2)) + Velx(i,j)*Vely(i,j)*xie(a,1)*xie(a,2)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + Pre(i,j)*(aa + 2)));
end
end
end

f0=maxw4;
f1=te2;

%%% TEMPORAL LOOP
time=0;
nt=150;
dt=tau;
for t=1:nt
time=time+dt;

%%% UPDATE DISTRIBUTION 
f0new=zeros(nx,ny,Q);
for i=mq+1:nx-mq
for j=mq+1:ny-mq
for a=1:Q
f0new(i+step(a,1),j+step(a,2),a)=f0(i,j,a);
end
end
end

f1new=zeros(nx,ny,Qe);
for i=mqe+1:nx-mqe
for j=mqe+1:ny-mqe
for a=1:Qe
f1new(i+stepe(a,1),j+stepe(a,2),a)=f1(i,j,a);
end
end
end

%%% APPLY BOUNDARY CONDITIONS 
count=1;
for b=1:Q
for i=1:mq+step(b,1)
for j=1:ny
for a=1:Q
f0new(i,j,count)=maxw4(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Q
for i=1:nx
for j=1:mq+step(b,2)
for a=1:Q
f0new(i,j,count)=maxw4(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Q
for i=nx-mq+1+step(b,1):nx
for j=1:ny
for a=1:Q
f0new(i,j,count)=maxw4(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Q
for i=1:nx
for j=ny-mq+1+step(b,2):ny
for a=1:Q
f0new(i,j,count)=maxw4(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Qe
for i=1:mqe+stepe(b,1)
for j=1:ny
for a=1:Qe
f1new(i,j,count)=te2(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Qe
for i=1:nx
for j=1:mqe+stepe(b,2)
for a=1:Qe
f1new(i,j,count)=te2(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Qe
for i=nx-mqe+1+stepe(b,1):nx
for j=1:ny
for a=1:Qe
f1new(i,j,count)=te2(i,j,count);
end
end
end
count=count+1;
end

count=1;
for b=1:Qe
for i=1:nx
for j=ny-mqe+1+stepe(b,2):ny
for a=1:Qe
f1new(i,j,count)=te2(i,j,count);
end
end
end
count=count+1;
end

%%% UPDATE MOMENTS
sum0=zeros(nx,ny);
sum1x=zeros(nx,ny);
sum1y=zeros(nx,ny);
for a=1:Q
sum0(:,:)=sum0(:,:)+f0new(:,:,a);
sum1x(:,:)=sum1x(:,:)+f0new(:,:,a)*xi(a,1);
sum1y(:,:)=sum1y(:,:)+f0new(:,:,a)*xi(a,2);
end

sum2=zeros(nx,ny);
for a=1:Qe
sum2(:,:)=sum2(:,:)+f1new(:,:,a);
end

Den=sum0;
Velx=sum1x./sum0;
Vely=sum1y./sum0;
Ene=sum2./sum0;
Tem=(Ene-Velx.^2-Vely.^2)./(Rs*(D+aa));
Pre=Den.*Rs.*Tem;

%%% UPDATE DISCRETE MAXWELLIAN 
f0=zeros(nx,ny,Q);
for i=1:nx
for j=1:ny
for a=1:Q
f0(i,j,a) = weight(a)*Den(i,j)*(...
	((xi(a,1)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ((xi(a,2)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + Velx(i,j)*xi(a,1) + Vely(i,j)*xi(a,2) + ...
	((xi(a,1)^4 - 6*xi(a,1)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Velx(i,j)^2 - 6*Rs*Tem(i,j) + Velx(i,j)^4 - 6*Velx(i,j)^2 + 3))/24 + ...
	((xi(a,2)^4 - 6*xi(a,2)^2 + 3)*(3*Rs*Tem(i,j)^2 + 6*Rs*Tem(i,j)*Vely(i,j)^2 - 6*Rs*Tem(i,j) + Vely(i,j)^4 - 6*Vely(i,j)^2 + 3))/24 + ...
	(Velx(i,j)*xi(a,1)*(xi(a,2)^2 - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/2 + (Vely(i,j)*xi(a,2)*(xi(a,1)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1))/2 + ...
	Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2) + (Velx(i,j)*xi(a,1)*(xi(a,1)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + (Vely(i,j)*xi(a,2)*(xi(a,2)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	((xi(a,1)^2 - 1)*(xi(a,2)^2 - 1)*(Velx(i,j)^2 + Rs*Tem(i,j) - 1)*(Vely(i,j)^2 + Rs*Tem(i,j) - 1))/4 + (Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2)*(xi(a,1)^2 - 3)*(Velx(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + ...
	(Velx(i,j)*Vely(i,j)*xi(a,1)*xi(a,2)*(xi(a,2)^2 - 3)*(Vely(i,j)^2 + 3*Rs*Tem(i,j) - 3))/6 + 1);
end
end
end

f1=zeros(nx,ny,Qe);
for i=1:nx
for j=1:ny
for a=1:Qe
f1(i,j,a)=we(a)*(0 - ((xie(a,1)^2 - 1)*(0 - Velx(i,j)^2*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + Pre(i,j)*(aa + 2)) - Rs*Tem(i,j)*0 + Pre(i,j)*(aa + 2) + Den(i,j)*Velx(i,j)^2 + ...
Den(i,j)*Vely(i,j)^2 - Pre(i,j)*(Velx(i,j)^2 + Vely(i,j)^2 + 2*Rs*Tem(i,j) + Rs*Tem(i,j)*(aa + 2))))/2 - ((xie(a,2)^2 - 1)*(0 - Vely(i,j)^2*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + ...
Pre(i,j)*(aa + 2)) - Rs*Tem(i,j)*0 + Pre(i,j)*(aa + 2) + Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 - Pre(i,j)*(Velx(i,j)^2 + Vely(i,j)^2 + 2*Rs*Tem(i,j) + Rs*Tem(i,j)*(aa + 2))))/2 + Pre(i,j)*(aa + 2) + ...
Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + Velx(i,j)*xie(a,1)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 2*Pre(i,j) + Pre(i,j)*(aa + 2)) + Vely(i,j)*xie(a,2)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + ...
2*Pre(i,j) + Pre(i,j)*(aa + 2)) + Velx(i,j)*Vely(i,j)*xie(a,1)*xie(a,2)*(Den(i,j)*Velx(i,j)^2 + Den(i,j)*Vely(i,j)^2 + 4*Pre(i,j) + Pre(i,j)*(aa + 2)));
end
end
end

end %time

%%% PLOT RESULTS

no=40;

figure
hold on
set(gcf,'color','white')

subplot(2,2,1)
hold on
title('DENSITY')
xlabel('x (m)')
ylabel('y (m)')
contour(xmat,ymat,Den,no,'black')
xlim([0 length])
ylim([0 height])
axis equal
grid on
hold off

subplot(2,2,2)
hold on
title('VELOCITY')
xlabel('x (m)')
ylabel('y (m)')
contour(xmat,ymat,(Velx.^2+Vely.^2).^(1/2),no,'black')
xlim([0 length])
ylim([0 height])
axis equal
grid on
hold off

subplot(2,2,3)
hold on
title('TEMPERATURE')
xlabel('x (m)')
ylabel('y (m)')
contour(xmat,ymat,Tem,no,'black')
xlim([0 length])
ylim([0 height])
axis equal
grid on
hold off

subplot(2,2,4)
hold on
title('PRESSURE')
xlabel('x (m)')
ylabel('y (m)')
contour(xmat,ymat,Pre,no,'black')
xlim([0 length])
ylim([0 height])
axis equal
grid on
hold off

hold off

% startx=0.1:0.1:1;
% starty=ones(size(startx));
% 
% figure
% hold on
% set(gcf,'color','white')
% quiver(xmat,ymat,Velx,Vely)
% %streamline(xmat,ymat,Velx,Vely,startx,starty)
% %surf(xmat,ymat,Den)
% %colormap turbo
% xlim([0 length])
% ylim([0 height])
% axis equal
% grid on
% hold off