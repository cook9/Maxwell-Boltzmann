clear all
close all

fprintf('Hermite series evaluation\n')

prompt='Number of dimensions: ';
D=input(prompt);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

if D==1
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));
end
if D==2
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2));
end
if D==3
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2+xi(3)^2));
end

h0=1;
h1=sym(zeros(D,1));
h2=sym(zeros(D,D));
h3=sym(zeros(D,D,D));
h4=sym(zeros(D,D,D,D));

a0=1;
a1=sym(zeros(D,1));
a2=sym(zeros(D,D));
a3=sym(zeros(D,D,D));
a4=sym(zeros(D,D,D,D));

ah0=1;
ah1=0;
ah2=0;
ah3=0;
ah4=0;

syms RT

% HERMITE POLYNOMIALS & MOMENTS

for i=1:D
h1(i)=xi(i);
a1(i)=v(i);
end

for i=1:D
for j=1:D
h2(i,j)=xi(i)*xi(j)-delta(i,j);
a2(i,j)=v(i)*v(j)+(RT-1)*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=xi(i)*xi(j)*xi(k)-(xi(i)*delta(j,k)+xi(j)*delta(i,k)+xi(k)*delta(i,j));
a3(i,j,k)=v(i)*v(j)*v(k)+(RT-1)*(v(i)*delta(j,k)+v(j)*delta(i,k)+v(k)*delta(i,j));
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l) = xi(i)*xi(j)*xi(k)*xi(l) - ...
xi(i)*xi(j)*delta(k,l) - xi(i)*xi(k)*delta(j,l) - xi(i)*xi(l)*delta(j,k) - ...
xi(j)*xi(k)*delta(i,l) - xi(j)*xi(l)*delta(i,k) - xi(k)*xi(l)*delta(i,j) + ...
delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(k,j);

a4(i,j,k,l) = v(i)*v(j)*v(k)*v(l) + (RT-1)*(...
v(i)*v(j)*delta(k,l) + v(i)*v(k)*delta(j,l) + v(i)*v(l)*delta(j,k) + ...
v(j)*v(k)*delta(i,l) + v(j)*v(l)*delta(i,k) + v(k)*v(l)*delta(i,j)) + ...
(delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(k,j))*(RT-1)^2;
end
end
end
end

% MOMENTS

e0=1;

e1=v;

e2=sym(zeros(D,D));
for i=1:D
for j=1:D
e2(i,j) = v(i)*v(j) + RT*delta(i,j);
end
end

e3=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
e3(i,j,k) = v(i)*v(j)*v(k) + RT*(v(i)*delta(j,k) + v(j)*delta(i,k) + v(k)*delta(i,j));
end
end
end

e4=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
e4(i,j,k,l) = v(i)*v(j)*v(k)*v(l) + ...
RT*(v(i)*v(j)*delta(k,l) + v(i)*v(k)*delta(j,l) + v(i)*v(l)*delta(j,k) + v(j)*v(k)*delta(i,l) + v(j)*v(l)*delta(i,k) + v(k)*v(l)*delta(i,j)) + ...
RT^2*(delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(k,j));
end
end
end
end

energy=0;
for i=1:D
energy=energy+e2(i,i);
end

flux=sym(zeros(D,1));
for i=1:D
for j=1:D
flux(j)=flux(j)+e3(i,i,j);
end
end

flux2=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
flux2(j,k)=flux2(j,k)+e4(i,i,j,k);
end
end
end

prompt='Moment number: ';
no=input(prompt);

if no==0

% INTEGRALS 0

int00=0;
int00=double(int(int(int(omega*h0,xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));

int01=zeros(D,1);
for i=1:D
int01(i)=double(int(int(int(omega*h1(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end

int02=zeros(D,D);
for i=1:D
for j=1:D
int02(i,j)=double(int(int(int(omega*h2(i,j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end

int03=zeros(D,D,D);
for i=1:D
for j=1:D
for k=1:D
int03(i,j,k)=double(int(int(int(omega*h3(i,j,k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end

int04=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
int04(i,j,k,l)=double(int(int(int(omega*h4(i,j,k,l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end

% TRUNCATED MOMENTS 0

sum00=0;
sum00=1/1*a0*int00;

sum01=0;
for i=1:D
sum01=sum01+1/1*a1(i)*int01(i);
end

sum02=0;
for i=1:D
for j=1:D
sum02=sum02+1/2*a2(i,j)*int02(i,j);
end
end

sum03=0;
for i=1:D
for j=1:D
for k=1:D
sum03=sum03+1/6*a3(i,j,k)*int03(i,j,k);
end
end
end

sum04=0;
for i=1:D
for j=1:D
for k=1:D
for l=1:D
sum04=sum04+1/24*a4(i,j,k,l)*int04(i,j,k,l);
end
end
end
end

moment0=sum00+sum01+sum02+sum03+sum04;

end

if no==1

% INTEGRALS 1

int10=sym(zeros(D,1));
for i=1:D
int10(i)=double(int(int(int(omega*h0*xi(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end

int11=zeros(D,D);
for i=1:D
for j=1:D
int11(i,j)=double(int(int(int(omega*h1(j)*xi(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end

int12=zeros(D,D,D);
for i=1:D
for j=1:D
for k=1:D
int12(i,j,k)=double(int(int(int(omega*h2(j,k)*xi(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end

int13=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
int13(i,j,k,l)=double(int(int(int(omega*h3(j,k,l)*xi(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end

int14=zeros(D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
int14(i,j,k,l,m)=double(int(int(int(omega*h4(j,k,l,m)*xi(i),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end

% TRUNCATED MOMENTS 1

sum10=sym(zeros(D,1));
sum10=1/1*a0*int10;

sum11=sym(zeros(D,1));
for i=1:D
for j=1:D
sum11(j)=sum11(j)+1/1*a1(i)*int11(i,j);
end
end

sum12=sym(zeros(D,1));
for i=1:D
for j=1:D
for k=1:D
sum12(k)=sum12(k)+1/2*a2(i,j)*int12(i,j,k);
end
end
end

sum13=sym(zeros(D,1));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
sum13(l)=sum13(l)+1/6*a3(i,j,k)*int13(i,j,k,l);
end
end
end
end

sum14=sym(zeros(D,1));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
sum14(m)=sum14(m)+1/24*a4(i,j,k,l)*int14(i,j,k,l,m);
end
end
end
end
end

moment1=sum10+sum11+sum12+sum13+sum14;

end

if no==2

% INTEGRALS 2

int20=zeros(D,D);
for i=1:D
for j=1:D
int20(i,j)=double(int(int(int(omega*h0*xi(i)*xi(j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end

int21=zeros(D,D,D);
for i=1:D
for j=1:D
for k=1:D
int21(i,j,k)=double(int(int(int(omega*h1(k)*xi(i)*xi(j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end

int22=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
int22(i,j,k,l)=double(int(int(int(omega*h2(k,l)*xi(i)*xi(j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end

int23=zeros(D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
int23(i,j,k,l,m)=double(int(int(int(omega*h3(k,l,m)*xi(i)*xi(j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end

int24=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
int24(i,j,k,l,m,n)=double(int(int(int(omega*h4(k,l,m,n)*xi(i)*xi(j),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end

% TRUNCATED MOMENTS 2

sum20=sym(zeros(D,D));
sum20=1/1*a0*int20;

sum21=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
sum21(j,k)=sum21(j,k)+1/1*a1(i)*int21(i,j,k);
end
end
end

sum22=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
sum22(k,l)=sum22(k,l)+1/2*a2(i,j)*int22(i,j,k,l);
end
end
end
end

sum23=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
sum23(l,m)=sum23(l,m)+1/6*a3(i,j,k)*int23(i,j,k,l,m);
end
end
end
end
end

sum24=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
sum24(m,n)=sum24(m,n)+1/24*a4(i,j,k,l)*int24(i,j,k,l,m,n);
end
end
end
end
end
end

moment2=sum20+sum21+sum22+sum23+sum24;

end

if no==3

% INTEGRALS 3

int30=zeros(D,D,D);
for i=1:D
for j=1:D
for k=1:D
int30(i,j,k)=double(int(int(int(omega*h0*xi(i)*xi(j)*xi(k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end

int31=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
int31(i,j,k,l)=double(int(int(int(omega*h1(l)*xi(i)*xi(j)*xi(k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end

int32=zeros(D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
int32(i,j,k,l,m)=double(int(int(int(omega*h2(l,m)*xi(i)*xi(j)*xi(k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end

int33=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
int33(i,j,k,l,m,n)=double(int(int(int(omega*h3(l,m,n)*xi(i)*xi(j)*xi(k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end

int34=zeros(D,D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
int34(i,j,k,l,m,n,o)=double(int(int(int(omega*h4(l,m,n,o)*xi(i)*xi(j)*xi(k),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end
end

% TRUNCATED MOMENTS 3

sum30=sym(zeros(D,D,D));
sum30=1/1*a0*int30;

sum31=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
sum31(j,k,l)=sum31(j,k,l)+1/1*a1(i)*int31(i,j,k,l);
end
end
end
end

sum32=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
sum32(k,l,m)=sum32(k,l,m)+1/2*a2(i,j)*int32(i,j,k,l,m);
end
end
end
end
end

sum33=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
sum33(l,m,n)=sum33(l,m,n)+1/6*a3(i,j,k)*int33(i,j,k,l,m,n);
end
end
end
end
end
end

sum34=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
sum34(m,n,o)=sum34(m,n,o)+1/24*a4(i,j,k,l)*int34(i,j,k,l,m,n,o);
end
end
end
end
end
end
end

moment3=simplify(sum30+sum31+sum32+sum33+sum34);

end

if no==4

% INTEGRALS 4

int40=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
int40(i,j,k,l)=double(int(int(int(omega*h0*xi(i)*xi(j)*xi(k)*xi(l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end

int41=zeros(D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
int41(i,j,k,l)=double(int(int(int(omega*h1(m)*xi(i)*xi(j)*xi(k)*xi(l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end

int42=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
int42(i,j,k,l,m,n)=double(int(int(int(omega*h2(m,n)*xi(i)*xi(j)*xi(k)*xi(l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end

int43=zeros(D,D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
int43(i,j,k,l,m,n,o)=double(int(int(int(omega*h3(m,n,o)*xi(i)*xi(j)*xi(k)*xi(l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end
end

int44=zeros(D,D,D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
int44(i,j,k,l,m,n,o,p)=double(int(int(int(omega*h4(m,n,o,p)*xi(i)*xi(j)*xi(k)*xi(l),xi1,-inf,inf),xi2,-inf,inf),xi3,-inf,inf));
end
end
end
end
end
end
end
end

% TRUNCATED MOMENTS 4

sum40=sym(zeros(D,D,D,D));
sum40=1/1*a0*int40;

sum41=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
sum41(j,k,l,m)=sum41(j,k,l,m)+1/1*a1(i)*int41(i,j,k,l,m);
end
end
end
end
end

sum42=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
sum42(k,l,m,n)=sum42(k,l,m,n)+1/2*a2(i,j)*int42(i,j,k,l,m,n);
end
end
end
end
end
end

sum43=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
sum43(l,m,n,o)=sum43(l,m,n,o)+1/6*a3(i,j,k)*int43(i,j,k,l,m,n,o);
end
end
end
end
end
end
end

sum44=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
sum44(m,n,o,p)=sum44(m,n,o,p)+1/24*a4(i,j,k,l)*int44(i,j,k,l,m,n,o,p);
end
end
end
end
end
end
end
end

moment4=simplify(sum40+sum41+sum42+sum43+sum44);

mflux2=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
mflux2(j,k)=mflux2(j,k)+moment4(i,i,j,k);
end
end
end

end

















































































































