clear all
close all
clc

prompt='Number of dimensions: ';
D=input(prompt);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

delta2=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2(i,j,k,l) = delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(j,k);
end
end
end
end

syms omega rho RT P a b

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

% HERMITE POLYNOMIALS

h0=1;
h1=sym(zeros(D,1));
h2=sym(zeros(D,D));
h3=sym(zeros(D,D,D));
h4=sym(zeros(D,D,D,D));
% h5=sym(zeros(D,D,D,D,D));

for i=1:D
h1(i)=xi(i);
end

for i=1:D
for j=1:D
h2(i,j)=xi(i)*xi(j)-delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=xi(i)*xi(j)*xi(k)-(xi(i)*delta(j,k)+xi(j)*delta(i,k)+xi(k)*delta(i,j));
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l) = xi(i)*xi(j)*xi(k)*xi(l) - (xi(i)*xi(j)*delta(k,l) + xi(i)*xi(k)*delta(j,l) + xi(i)*xi(l)*delta(j,k) + xi(j)*xi(k)*delta(i,l) + xi(j)*xi(l)*delta(i,k) + xi(k)*xi(l)*delta(i,j)) + delta2(i,j,k,l);
end
end
end
end

% for i=1:D
% for j=1:D
% for k=1:D
% for l=1:D
% for m=1:D
% h5(i,j,k,l,m) = xi(i)*xi(j)*xi(k)*xi(l)*xi(m) - (...
% xi(i)*xi(j)*xi(k)*delta(l,m) + xi(i)*xi(j)*xi(l)*delta(k,m) + xi(i)*xi(k)*xi(l)*delta(j,m) + xi(j)*xi(k)*xi(l)*delta(i,m) + xi(i)*xi(j)*xi(m)*delta(k,l) + ...
% xi(i)*xi(k)*xi(m)*delta(j,l) + xi(j)*xi(k)*xi(m)*delta(i,l) + xi(i)*xi(l)*xi(m)*delta(j,k) + xi(j)*xi(l)*xi(m)*delta(i,k) + xi(k)*xi(l)*xi(m)*delta(i,j) ) + ...
% xi(i)*delta2(j,k,l,m) + xi(j)*delta2(i,k,l,m) + xi(k)*delta2(j,i,l,m) + xi(l)*delta2(j,k,i,m) + xi(m)*delta2(j,k,l,i) ;
% end
% end
% end
% end
% end

h1=simplify(h1);
h2=simplify(h2);
h3=simplify(h3);
h4=simplify(h4);
% h5=simplify(h5);

% MAXWELLIAN COEFFICIENTS

a0=1;
a1=sym(zeros(D,1));
a2=sym(zeros(D,D));
a3=sym(zeros(D,D,D));
a4=sym(zeros(D,D,D,D));

for i=1:D
a1(i)=v(i);
end

for i=1:D
for j=1:D
a2(i,j)=v(i)*v(j)+(RT-1)*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
a3(i,j,k)=v(i)*v(j)*v(k)+(RT-1)*(v(i)*delta(j,k)+v(j)*delta(i,k)+v(k)*delta(i,j));
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
a4(i,j,k,l) = v(i)*v(j)*v(k)*v(l) + (RT-1)*(v(i)*v(j)*delta(k,l) + v(i)*v(k)*delta(j,l) + v(i)*v(l)*delta(j,k) + v(j)*v(k)*delta(i,l) + v(j)*v(l)*delta(i,k) + v(k)*v(l)*delta(i,j)) + (RT-1)^2*delta2(i,j,k,l);
end
end
end
end

a1=simplify(a1);
a2=simplify(a2);
a3=simplify(a3);
a4=simplify(a4);

% DEFINE ENERGY

rhoE=0;
for i=1:D
rhoE=rhoE+rho*v(i)^2;
end
rhoE=rhoE+(D+a)*P;

E=0;
for i=1:D
E=E+v(i)^2;
end
E=E+(D+a)*RT;

% TOTAL ENERGY COEFFICIENTS

b0=rhoE+b;
b1=sym(zeros(D,1));
b2=sym(zeros(D,D));
b3=sym(zeros(D,D,D));

for i=1:D
b1(i)=(rhoE+2*P)*v(i);
end

for i=1:D
for j=1:D
b2(i,j) = (rhoE + 4*P)*v(i)*v(j) + (P*(E + 2*RT) + b*RT - (rhoE + b))*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
b3(i,j,k) = (rhoE + 6*P)*v(i)*v(j)*v(k) + (P*(E+4*RT)-(rhoE+2*P))*(v(i)*delta(j,k)+v(j)*delta(i,k)+v(k)*delta(i,j));
end
end
end

% MODIFIED VELOCITY COEFFICIENTS

c0=sym(zeros(D,1));
c1=sym(zeros(D,D));
c2=sym(zeros(D,D,D));
c3=sym(zeros(D,D,D,D));

for i=1:D
c0(i)=v(i);
end

for i=1:D
for j=1:D
c1(i,j) = v(i)*v(j) + RT*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
c2(i,j,k) = v(i)*v(j)*v(k) + RT*(v(i)*delta(j,k)+v(j)*delta(i,k)) + (RT-1)*v(k)*delta(i,j);
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
c3(i,j,k,l) = v(i)*v(j)*v(k)*v(l) + RT*(v(i)*v(j)*delta(k,l)+v(i)*v(k)*delta(j,l)+v(j)*v(k)*delta(i,l)) + (RT-1)*(v(i)*v(l)*delta(j,k)+v(j)*v(l)*delta(i,k)+v(k)*v(l)*delta(i,j)) + (RT-1)*RT*delta2(i,j,k,l);
end
end
end
end

% CONTRACTIONS

ah0=a0*h0;
ah1=0;
ah2=0;
ah3=0;
ah4=0;

for i=1:D
ah1=ah1+a1(i)*h1(i);
end

for i=1:D
for j=1:D
ah2=ah2+a2(i,j)*h2(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
ah3=ah3+a3(i,j,k)*h3(i,j,k);
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
ah4=ah4+a4(i,j,k,l)*h4(i,j,k,l);
end
end
end
end

bh0=b0*h0;
bh1=0;
bh2=0;
bh3=0;

for i=1:D
bh1=bh1+b1(i)*h1(i);
end

for i=1:D
for j=1:D
bh2=bh2+b2(i,j)*h2(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
bh3=bh3+b3(i,j,k)*h3(i,j,k);
end
end
end

ch0=c0*h0;
ch1=sym(zeros(D,1));
ch2=sym(zeros(D,1));
ch3=sym(zeros(D,1));

for i=1:D
for j=1:D
ch1(i)=ch1(i)+c1(i,j)*h1(j);
end
end

for i=1:D
for j=1:D
for k=1:D
ch2(i)=ch2(i)+c2(i,j,k)*h2(j,k);
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
ch3(i)=ch3(i)+c3(i,j,k,l)*h3(j,k,l);
end
end
end
end

% HERMITE EXPANDED MAXWELLIAN

N=4;
M=3;
U=3;

ah=sym(zeros(N+1,1));
if N==0
ah(1)=ah0;
end
if N==1
ah(1)=ah0;ah(2)=ah1;
end
if N==2
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;
end
if N==3
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;
end
if N==4
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;
end

bh=sym(zeros(M+1,1));
if M==0
bh(1)=bh0;
end
if M==1
bh(1)=bh0;bh(2)=bh1;
end
if M==2
bh(1)=bh0;bh(2)=bh1;bh(3)=bh2;
end
if M==3
bh(1)=bh0;bh(2)=bh1;bh(3)=bh2;bh(4)=bh3;
end

ch=sym(zeros(U+1,D));
if U==0
for i=1:D
ch(1,i)=ch0(i);
end
end
if U==1
for i=1:D
ch(1,i)=ch0(i);ch(2,i)=ch1(i);
end
end
if U==2
for i=1:D
ch(1,i)=ch0(i);ch(2,i)=ch1(i);ch(3,i)=ch2(i);
end
end
if U==3
for i=1:D
ch(1,i)=ch0(i);ch(2,i)=ch1(i);ch(3,i)=ch2(i);ch(4,i)=ch3(i);
end
end

maxs=0;
for n=1:N+1
maxs=maxs+1/factorial(n-1)*ah(n);
end
maxs=simplify(maxs*rho*omega);

tens=0;
for m=1:M+1
tens=tens+1/factorial(m-1)*bh(m);
end
tens=simplify(tens*omega);

vels=sym(zeros(D,1));
for i=1:D
for u=1:U+1
vels(i)=vels(i)+1/factorial(u-1)*ch(u,i);
end
end
vels=simplify(vels*omega);

maxs
tens
vels