clear all
close all
clc

fprintf('HERMITE SERIES EXPANSION\n')

prompt='Number of dimensions: ';
D=input(prompt);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

delta2=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2(i,j,k,l) = delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(j,k);
end
end
end
end

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

if D==1
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));
end
if D==2
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2));
end
if D==3
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2+xi(3)^2));
end

syms rho RT
f=1;
for i=1:D
f=f/sqrt(2*pi*(RT-1))*exp(1/(2*(RT-1))*v(i)^2);
end
f=f*rho;

% HERMITE POLYNOMIALS

h0=1;
h1=sym(zeros(D,1));
h2=sym(zeros(D,D));
h3=sym(zeros(D,D,D));
h4=sym(zeros(D,D,D,D));
h5=sym(zeros(D,D,D,D,D));
h6=sym(zeros(D,D,D,D,D,D));
h7=sym(zeros(D,D,D,D,D,D,D));
h8=sym(zeros(D,D,D,D,D,D,D,D));
h9=sym(zeros(D,D,D,D,D,D,D,D,D));
h10=sym(zeros(D,D,D,D,D,D,D,D,D,D));

a0=1;
a1=sym(zeros(D,1));
a2=sym(zeros(D,D));
a3=sym(zeros(D,D,D));
a4=sym(zeros(D,D,D,D));
a5=sym(zeros(D,D,D,D,D));
a6=sym(zeros(D,D,D,D,D,D));
a7=sym(zeros(D,D,D,D,D,D,D));
a8=sym(zeros(D,D,D,D,D,D,D,D));
a9=sym(zeros(D,D,D,D,D,D,D,D,D));
a10=sym(zeros(D,D,D,D,D,D,D,D,D,D));

for i=1:D
h1(i)=(-1)^1/omega*diff(omega,xi(i));
a1(i)=diff(f,v(i))/f*(RT-1)^1;
end

for i=1:D
for j=1:D
h2(i,j)=(-1)^2/omega*diff(diff(omega,xi(i)),xi(j));
a2(i,j)=diff(diff(f,v(i)),v(j))/f*(RT-1)^2;
end
end

for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=(-1)^3/omega*diff(diff(diff(omega,xi(i)),xi(j)),xi(k));
a3(i,j,k)=diff(diff(diff(f,v(i)),v(j)),v(k))/f*(RT-1)^3;
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l)=(-1)^4/omega*diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l));
a4(i,j,k,l)=diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l))/f*(RT-1)^4;
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
h5(i,j,k,l,m)=(-1)^5/omega*diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m));
a5(i,j,k,l,m)=diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m))/f*(RT-1)^5;
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
h6(i,j,k,l,m,n)=(-1)^6/omega*diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n));
a6(i,j,k,l,m,n)=diff(diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m)),v(n))/f*(RT-1)^6;
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
h7(i,j,k,l,m,n,o)=(-1)^7/omega*diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o));
a7(i,j,k,l,m,n,o)=diff(diff(diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m)),v(n)),v(o))/f*(RT-1)^7;
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
h8(i,j,k,l,m,n,o,p)=(-1)^8/omega*diff(diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o)),xi(p));
a8(i,j,k,l,m,n,o,p)=diff(diff(diff(diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m)),v(n)),v(o)),v(p))/f*(RT-1)^8;
end
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for q=1:D
h9(i,j,k,l,m,n,o,p,q)=(-1)^9/omega*diff(diff(diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o)),xi(p)),xi(q));
a9(i,j,k,l,m,n,o,p,q)=diff(diff(diff(diff(diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m)),v(n)),v(o)),v(p)),v(q))/f*(RT-1)^9;
end
end
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for q=1:D
for r=1:D
h10(i,j,k,l,m,n,o,p,q,r)=(-1)^10/omega*diff(diff(diff(diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o)),xi(p)),xi(q)),xi(r));
a10(i,j,k,l,m,n,o,p,q,r)=diff(diff(diff(diff(diff(diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m)),v(n)),v(o)),v(p)),v(q)),v(r))/f*(RT-1)^10;
end
end
end
end
end
end
end
end
end
end

h1=simplify(h1);
h2=simplify(h2);
h3=simplify(h3);
h4=simplify(h4);
h5=simplify(h5);
h6=simplify(h6);
h7=simplify(h7);
h8=simplify(h8);
h9=simplify(h9);
h10=simplify(h10);

a1=simplify(a1);
a2=simplify(a2);
a3=simplify(a3);
a4=simplify(a4);
a5=simplify(a5);
a6=simplify(a6);
a7=simplify(a7);
a8=simplify(a8);
a9=simplify(a9);
a10=simplify(a10);

ah0=a0*h0;
ah1=0;
ah2=0;
ah3=0;
ah4=0;
ah5=0;
ah6=0;
ah7=0;
ah8=0;
ah9=0;
ah10=0;

for i=1:D
ah1=ah1+a1(i)*h1(i);
end

for i=1:D
for j=1:D
ah2=ah2+a2(i,j)*h2(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
ah3=ah3+a3(i,j,k)*h3(i,j,k);
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
ah4=ah4+a4(i,j,k,l)*h4(i,j,k,l);
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
ah5=ah5+a5(i,j,k,l,m)*h5(i,j,k,l,m);
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
ah6=ah6+a6(i,j,k,l,m,n)*h6(i,j,k,l,m,n);
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
ah7=ah7+a7(i,j,k,l,m,n,o)*h7(i,j,k,l,m,n,o);
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
ah8=ah8+a8(i,j,k,l,m,n,o,p)*h8(i,j,k,l,m,n,o,p);
end
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for q=1:D
ah9=ah9+a9(i,j,k,l,m,n,o,p,q)*h9(i,j,k,l,m,n,o,p,q);
end
end
end
end
end
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for q=1:D
for r=1:D
ah10=ah10+a10(i,j,k,l,m,n,o,p,q,r)*h10(i,j,k,l,m,n,o,p,q,r);
end
end
end
end
end
end
end
end
end
end

prompt='Expansion number: ';
N=input(prompt);

ah=sym(zeros(N+1,1));
if N==0
ah(1)=ah0;
end
if N==1
ah(1)=ah0;ah(2)=ah1;
end
if N==2
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;
end
if N==3
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;
end
if N==4
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;
end
if N==5
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;
end
if N==6
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;ah(7)=ah6;
end
if N==7
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;ah(7)=ah6;ah(8)=ah7;
end
if N==8
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;ah(7)=ah6;ah(8)=ah7;ah(9)=ah8;
end
if N==9
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;ah(7)=ah6;ah(8)=ah7;ah(9)=ah8;ah(10)=ah9;
end
if N==10
ah(1)=ah0;ah(2)=ah1;ah(3)=ah2;ah(4)=ah3;ah(5)=ah4;ah(6)=ah5;ah(7)=ah6;ah(8)=ah7;ah(9)=ah8;ah(10)=ah9;ah(11)=ah10;
end

maxs=0;
for n=1:N+1
maxs=maxs+1/factorial(n-1)*ah(n);
end

syms weight
maxs=simplify(maxs*rho*weight);
maxs