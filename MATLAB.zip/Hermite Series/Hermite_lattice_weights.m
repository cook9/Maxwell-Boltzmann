clear all
close all
clc

fprintf('GAUSS-HERMITE LATTICE AND WEIGHT DERIVATIONS AND CHECKS\n')

%%% 1D LATTICE & WEIGHTS

D=1;
xi=sym(zeros(D,1));
syms xi1
xi(1)=xi1;
v=sym(zeros(D,1));
syms v1
v(1)=v1;
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));

prompt='Number of lattices: ';
Q=input(prompt);
mq=(Q-1)/2;
hermite=sym(zeros(Q,1));
hermite(1)=1;
for a=2:Q
hermite(a)=(-1)^(a-1)/omega*diff(omega,xi1,a-1);
end
hermite=simplify(hermite);

integral=sym(zeros(Q,1));
for a=1:Q
integral(a)=int(omega*hermite(a),xi1,-inf,inf);
end
integral=double(integral);

if D==1
c=1;
count=0;
lat=sym(zeros(Q,D));
for a=2:Q
if mod(a,2)==0
count=count+1;
lat(a)= 0 + count*c;
else
lat(a)= 0 - count*c;
end
end

w=sym('w',[Q 1]);
veceq=sym(zeros(Q,1));
for a=1:Q
for i=1:Q
veceq(i)=veceq(i)+w(a)*subs(hermite(i),xi1,lat(a));
end
end

[mat]=equationsToMatrix(veceq,w);
weight=simplify(inv(mat)*integral);

end % if D==1

%%% ADD DIMENSIONS

prompt='Number of dimensions: ';
D=input(prompt);

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

if D==1
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));
end
if D==2
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2));
end
if D==3
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2+xi(3)^2));
end

if D==1
new_weight=weight;
new_lat=lat;
end

if D==2
new_weight=sym(zeros(Q^D,1));
new_lat=sym(zeros(Q^D,D));
count=0;
for a=1:Q
for b=1:Q
count=count+1;
new_weight(count)=weight(a)*weight(b);
new_lat(count,1)=lat(a);
new_lat(count,2)=lat(b);
end
end
end

if D==3
new_weight=sym(zeros(Q^D,1));
new_lat=sym(zeros(Q^D,D));
count=0;
for a=1:Q
for b=1:Q
for d=1:Q
count=count+1;
new_weight(count)=weight(a)*weight(b)*weight(d);
new_lat(count,1)=lat(a);
new_lat(count,2)=lat(b);
new_lat(count,3)=lat(d);
end
end
end
end

new_weight=simplify(new_weight);
Qtot=Q^D;

prompt='Check sums? (1 = yes, 0 = no) ';
check=input(prompt);

if check ==1

%%% CHECK SUMS

sum0=0;
for a=1:Qtot
sum0=sum0+new_weight(a);
end
sum0=double(simplify(sum0));
sum0

sum1=sym(zeros(D,1));
for i=1:D
for a=1:Qtot
sum1(i)=sum1(i)+new_weight(a)*new_lat(a,i);
end
end
sum1=double(simplify(sum1));
sum1

sum2=sym(zeros(D,D));
for i=1:D
for j=1:D
for a=1:Qtot
sum2(i,j)=sum2(i,j)+new_weight(a)*new_lat(a,i)*new_lat(a,j);
end
end
end
sum2=double(simplify(sum2));
sum2

sum3=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for a=1:Qtot
sum3(i,j,k)=sum3(i,j,k)+new_weight(a)*new_lat(a,i)*new_lat(a,j)*new_lat(a,k);
end
end
end
end
sum3=double(simplify(sum3));
sum3

if Q>5
sum4=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for a=1:Qtot
sum4(i,j,k,l)=sum4(i,j,k,l)+new_weight(a)*new_lat(a,i)*new_lat(a,j)*new_lat(a,k)*new_lat(a,l);
end
end
end
end
end
sum4=double(simplify(sum4));
sum4
end

if Q>7
sum5=sym(zeros(D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for a=1:Qtot
sum5(i,j,k,l,m)=sum5(i,j,k,l,m)+new_weight(a)*new_lat(a,i)*new_lat(a,j)*new_lat(a,k)*new_lat(a,l)*new_lat(a,m);
end
end
end
end
end
end
sum5=double(simplify(sum5));
sum5
end

%%% CHECK H2 SUMS

n=2;
h2=sym(zeros(D,D));
for i=1:D
for j=1:D
h2(i,j)=(-1)^n/omega*diff(diff(omega,xi(i)),xi(j));
end
end
h2=simplify(h2);

h2new_lat=sym(zeros(D,D,Qtot));
for a=1:Qtot
h2new_lat(:,:,a)=h2(:,:);
if D==1
h2new_lat(:,:,a)=subs(h2(:,:),{xi1},{new_lat(a,1)});
end
if D==2
h2new_lat(:,:,a)=subs(h2(:,:),{xi1 xi2},{new_lat(a,1) new_lat(a,2)});
end
if D==3
h2new_lat(:,:,a)=subs(h2(:,:),{xi1 xi2 xi3},{new_lat(a,1) new_lat(a,2) new_lat(a,3)});
end
end

sum0h2=sym(zeros(D,D));
for i=1:D
for j=1:D
for a=1:Qtot
sum0h2(i,j)=sum0h2(i,j)+new_weight(a)*h2new_lat(i,j,a);
end
end
end
sum0h2=double(simplify(sum0h2));
sum0h2

sum1h2=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for a=1:Qtot
sum1h2(i,j,k)=sum1h2(i,j,k)+new_weight(a)*h2new_lat(i,j,a)*new_lat(a,k);
end
end
end
end
sum1h2=double(simplify(sum1h2));
sum1h2

sum2h2=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for a=1:Qtot
sum2h2(i,j,k,l)=sum2h2(i,j,k,l)+new_weight(a)*h2new_lat(i,j,a)*new_lat(a,k)*new_lat(a,l);
end
end
end
end
end
sum2h2=double(simplify(sum2h2));
sum2h2

if Q>5
sum3h2=sym(zeros(D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for a=1:Qtot
sum3h2(i,j,k,l,m)=sum3h2(i,j,k,l,m)+new_weight(a)*h2new_lat(i,j,a)*new_lat(a,k)*new_lat(a,l)*new_lat(a,m);
end
end
end
end
end
end
sum3h2=double(simplify(sum3h2));
sum3h2
end

if Q>7
sum4h2=sym(zeros(D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for a=1:Qtot
sum4h2(i,j,k,l,m,n)=sum4h2(i,j,k,l,m,n)+new_weight(a)*h2new_lat(i,j,a)*new_lat(a,k)*new_lat(a,l)*new_lat(a,m)*new_lat(a,n);
end
end
end
end
end
end
end
sum4h2=double(simplify(sum4h2));
sum4h2
end

%%% CHECK H3 SUMS

if Q>5
n=3;
h3=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=(-1)^n/omega*diff(diff(diff(omega,xi(i)),xi(j)),xi(k));
end
end
end
h3=simplify(h3);

h3new_lat=sym(zeros(D,D,D,Qtot));
for a=1:Qtot
h3new_lat(:,:,:,a)=h3(:,:,:);
if D==1
h3new_lat(:,:,:,a)=subs(h3(:,:,:),{xi1},{new_lat(a,1)});
end
if D==2
h3new_lat(:,:,:,a)=subs(h3(:,:,:),{xi1 xi2},{new_lat(a,1) new_lat(a,2)});
end
if D==3
h3new_lat(:,:,:,a)=subs(h3(:,:,:),{xi1 xi2 xi3},{new_lat(a,1) new_lat(a,2) new_lat(a,3)});
end
end

sum0h3=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
for a=1:Qtot
sum0h3(i,j,k)=sum0h3(i,j,k)+new_weight(a)*h3new_lat(i,j,k,a);
end
end
end
end
sum0h3=double(simplify(sum0h3));
sum0h3

sum1h3=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for a=1:Qtot
sum1h3(i,j,k,l)=sum1h3(i,j,k,l)+new_weight(a)*h3new_lat(i,j,k,a)*new_lat(a,l);
end
end
end
end
end
sum1h3=double(simplify(sum1h3));
sum1h3

sum2h3=sym(zeros(D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for a=1:Qtot
sum2h3(i,j,k,l,m)=sum2h3(i,j,k,l,m)+new_weight(a)*h3new_lat(i,j,k,a)*new_lat(a,l)*new_lat(a,m);
end
end
end
end
end
end
sum2h3=double(simplify(sum2h3));
sum2h3

sum3h3=sym(zeros(D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for a=1:Qtot
sum3h3(i,j,k,l,m,n)=sum3h3(i,j,k,l,m,n)+new_weight(a)*h3new_lat(i,j,k,a)*new_lat(a,l)*new_lat(a,m)*new_lat(a,n);
end
end
end
end
end
end
end
sum3h3=double(simplify(sum3h3));
sum3h3
end

if Q>7
sum4h3=sym(zeros(D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for a=1:Qtot
sum4h3(i,j,k,l,m,n,o)=sum4h3(i,j,k,l,m,n,o)+new_weight(a)*h3new_lat(i,j,k,a)*new_lat(a,l)*new_lat(a,m)*new_lat(a,n)*new_lat(a,o);
end
end
end
end
end
end
end
end
sum4h3=double(simplify(sum4h3));
sum4h3
end

%%% CHECK H4 SUMS

if Q>7
n=4;
h4=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l)=(-1)^n/omega*diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l));
end
end
end
end
h4=simplify(h4);

h4new_lat=sym(zeros(D,D,D,D,Qtot));
for a=1:Qtot
h4new_lat(:,:,:,:,a)=h4(:,:,:,:);
if D==1
h4new_lat(:,:,:,:,a)=subs(h4(:,:,:,:),{xi1},{new_lat(a,1)});
end
if D==2
h4new_lat(:,:,:,:,a)=subs(h4(:,:,:,:),{xi1 xi2},{new_lat(a,1) new_lat(a,2)});
end
if D==3
h4new_lat(:,:,:,:,a)=subs(h4(:,:,:,:),{xi1 xi2 xi3},{new_lat(a,1) new_lat(a,2) new_lat(a,3)});
end
end

sum0h4=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for a=1:Qtot
sum0h4(i,j,k,l)=sum0h4(i,j,k,l)+new_weight(a)*h4new_lat(i,j,k,l,a);
end
end
end
end
end
sum0h4=double(simplify(sum0h4));
sum0h4

sum1h4=sym(zeros(D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for a=1:Qtot
sum1h4(i,j,k,l,m)=sum1h4(i,j,k,l,m)+new_weight(a)*h4new_lat(i,j,k,m,a)*new_lat(a,l);
end
end
end
end
end
end
sum1h4=double(simplify(sum1h4));
sum1h4

sum2h4=sym(zeros(D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for a=1:Qtot
sum2h4(i,j,k,l,m,n)=sum2h4(i,j,k,l,m,n)+new_weight(a)*h4new_lat(i,j,k,l,a)*new_lat(a,m)*new_lat(a,n);
end
end
end
end
end
end
end
sum2h4=double(simplify(sum2h4));
sum2h4

sum3h4=sym(zeros(D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for a=1:Qtot
sum3h4(i,j,k,l,m,n,o)=sum3h4(i,j,k,l,m,n,o)+new_weight(a)*h4new_lat(i,j,k,l,a)*new_lat(a,m)*new_lat(a,n)*new_lat(a,o);
end
end
end
end
end
end
end
end
sum3h4=double(simplify(sum3h4));
sum3h4

sum4h4=sym(zeros(D,D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for a=1:Qtot
sum4h4(i,j,k,l,m,n,o,p)=sum4h4(i,j,k,l,m,n,o,p)+new_weight(a)*h4new_lat(i,j,k,l,a)*new_lat(a,m)*new_lat(a,n)*new_lat(a,o)*new_lat(a,p);
end
end
end
end
end
end
end
end
end
sum4h4=double(simplify(sum4h4));
sum4h4
end

end % if check