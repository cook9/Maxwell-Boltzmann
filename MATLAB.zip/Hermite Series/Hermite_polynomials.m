clear all
close all

D=3;

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

if D==1
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));
end
if D==2
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2));
end
if D==3
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2+xi(3)^2));
end

HERMITE POLYNOMIALS

n=0;
h0=1;

n=1;
h1=sym(zeros(D,1));
for i=1:D
h1(i)=(-1)^n/omega*diff(omega,xi(i));
end

n=2;
h2=sym(zeros(D,D));
for i=1:D
for j=1:D
h2(i,j)=(-1)^n/omega*diff(diff(omega,xi(i)),xi(j));
end
end
h2=simplify(h2);

n=3;
h3=sym(zeros(D,D,D));
for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=(-1)^n/omega*diff(diff(diff(omega,xi(i)),xi(j)),xi(k));
end
end
end
h3=simplify(h3);

n=4;
h4=sym(zeros(D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l)=(-1)^n/omega*diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l));
end
end
end
end
h4=simplify(h4);

n=5;
h5=sym(zeros(D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
h5(i,j,k,l,m)=(-1)^n/omega*diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m));
end
end
end
end
end
h5=simplify(h5);

nn=6;
h6=sym(zeros(D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
h6(i,j,k,l,m,n)=(-1)^nn/omega*diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n));
end
end
end
end
end
end
h6=simplify(h6);

nn=7;
h7=sym(zeros(D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
h7(i,j,k,l,m,n,o)=(-1)^nn/omega*diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o));
end
end
end
end
end
end
end
h7=simplify(h7);

nn=8;
h8=sym(zeros(D,D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
h8(i,j,k,l,m,n,o,p)=(-1)^nn/omega*diff(diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o)),xi(p));
end
end
end
end
end
end
end
end
h8=simplify(h8);

nn=9;
h9=sym(zeros(D,D,D,D,D,D,D,D,D));
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
for q=1:D
h9(i,j,k,l,m,n,o,p,q)=(-1)^nn/omega*diff(diff(diff(diff(diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m)),xi(n)),xi(o)),xi(p)),xi(q));
end
end
end
end
end
end
end
end
end
h9=simplify(h9);