clear all
close all

% BLACKSBURG, VA
% 01/30/2021

MSL=630;
Tem=275;
Den=1.3;
Rs=287.05;

D=1;
x1=100;
tau=1;
vv=[-500:5.0:500];
tt=[0.01:0.2:20];
[v1,t1]=meshgrid(vv,tt);
m1=Den*(t1./(2*pi*Rs*Tem*tau)).^(D/2).*exp(-1/(2*Rs*Tem*tau)*(v1.^2.*t1 + x1.^2./t1 - 2*v1.*x1));

t2=20;
xx=[-1000:20.0:1000];
vv=[-1000:20.0:1000];
[v2,x2]=meshgrid(vv,xx);
m2=Den*(t2./(2*pi*Rs*Tem*tau)).^(D/2).*exp(-1/(2*Rs*Tem*tau)*(v2.^2.*t2 + x2.^2./t2 - 2*v2.*x2));

U=0;
A=1;
S=1;
%% VV=[0.01:0.1:5];
VV=[-10:1.0:10];
TT=[0.01:0.1:10];
[V,T]=meshgrid(VV,TT);
normal=1/sqrt(2*pi*S^2)*exp(-1/(2*S^2)*(V-U-A*T).^2);

figure
hold on
set(gcf,'color','white')

subplot(2,2,1)
hold on
title('FIXED SPACE')
xlabel('t')
ylabel('\xi')
zlabel('M(\xi,t)')
surf(t1,v1,m1)
view(60,10)
colormap(flipud(turbo))
grid on
axis on
hold off

subplot(2,2,2)
hold on
title('FIXED TIME (t=20s)')
xlabel('\xi')
ylabel('x')
zlabel('M(\xi,x)')
surf(v2,x2,m2)
view(150,15)
colormap(flipud(turbo))
grid on
axis on
hold off

subplot(2,2,3)
hold on
title('DISTRIBUTION EVOLUTION') 
xlabel('\xi')
ylabel('t')
zlabel('N(\xi,t)')
surf(V,T,normal)
view(90,0)
colormap(flipud(turbo))
grid on
axis on
hold off

subplot(2,2,4)
hold on
title('"PARTICLE" EVOLUTION') 
xlabel('\xi')
ylabel('t')
zlabel('N(\xi,t)')
surf(V,T,normal)
view(0,90)
colormap(flipud(turbo))
grid on
axis on
hold off

hold off

%% set(gca,'XTickLabel',[],'YTickLabel',[],'ZTickLabel',[])
%% set(gca,'XTick',[],'YTick',[],'ZTick',[])