clear all
close all

D=1;
Q=7;
no=(Q-1)/2;
syms c
lat=sym(zeros(Q,1));
lat(1)=  0*c;
lat(2)=  1*c;
lat(3)= -1*c;
lat(4)=  2*c;
lat(5)= -2*c;
lat(6)=  3*c;
lat(7)= -3*c;
%lat(8)=  4*c;
%lat(9)= -4*c;

D=2;
new_lat=sym(zeros(Q^2,D));
count=0;
for a=1:Q
for b=1:Q
count=count+1;
new_lat(count,1)=lat(a);
new_lat(count,2)=lat(b);
end
end

new_lat=double(new_lat/c);





figure
hold on

set(gcf,'Color','white')
set(gca,'FontName','times')
set(gca,'FontSize',12)
set(gca,'DefaultAxesTitleFontWeight','normal')

%set(gca,'XTickLabel',[])
%set(gca,'YTickLabel',[])
%ax1=gca;
%ax1.YAxis.Visible='on';
%ax1.XAxis.Visible='on';
%ax1.XAxisLocation='origin';
%ax1.YAxisLocation='origin';



for a=1:Q^D
quiver(0,0,new_lat(a,1),new_lat(a,2),0,'Color','black')
end
xlim([-no no])
ylim([-no no])
grid on
axis equal
hold off