clear all
close all

D=1;
Q=7;

syms c
lat=sym(zeros(Q,1));
lat(1)=  0*c;
lat(2)=  1*c;
lat(3)= -1*c;
lat(4)=  2*c;
lat(5)= -2*c;
lat(6)=  3*c;
lat(7)= -3*c;



figure
hold on
set(gca,'FontName','times')
set(gca,'FontSize',12)
set(gca,'YTickLabel',[])
set(gca,'DefaultAxesTitleFontWeight','normal')
ax1=gca;
ax1.YAxis.Visible='off';
ax1.XAxis.Visible='on';
title('D1Q7 LATTICE')
xlabel('\xi_{\alpha}/c')
for a=1:Q
quiver(0,0,double(lat(a)/c),0,0,'Color','black')
end
scatter(0,0,'filled','black')
xlim([-3 3])
ylim([-1 1])
grid off
axis square
hold off