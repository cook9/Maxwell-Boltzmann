clear all
close all

D=1;
Q=7;

syms c
weight=sym(zeros(Q,1));
weight(1:1)=(36*c^6 - 49*c^4 + 42*c^2 - 15)/(36*c^6);
weight(2:3)=(12*c^4 - 13*c^2 + 5)/(16*c^6);
weight(4:5)=-(3*c^4 - 10*c^2 + 5)/(40*c^6);
weight(6:7)=(4*c^4 - 15*c^2 + 15)/(720*c^6);

lat=sym(zeros(Q,1));
lat(1)=  0*c;
lat(2)=  1*c;
lat(3)= -1*c;
lat(4)=  2*c;
lat(5)= -2*c;
lat(6)=  3*c;
lat(7)= -3*c;





figure
hold on
set(gcf,'Color','white')
set(gca,'FontName','times')
set(gca,'FontSize',12)
%set(gca,'XTickLabel',[])
%set(gca,'YTickLabel',[])
set(gca,'DefaultAxesTitleFontWeight','normal')
%ax1=gca;
%ax1.YAxis.Visible='on';
%ax1.XAxis.Visible='on';
%ax1.XAxisLocation='origin';
%ax1.YAxisLocation='origin';
%title('GAUSS-HERMITE WEIGHTS')
%xlabel('c (m/s)')
%ylabel('w_{\alpha}')

xl=xline(0,'LineStyle','-','LineWidth',1)
yl=yline(0,'LineStyle','-','LineWidth',1)


fplot(weight(1),'LineStyle','-','Color','black')
fplot(weight(2),'LineStyle','--','Color','black')
fplot(weight(4),'LineStyle',':','Color','black','LineWidth',1)
fplot(weight(6),'LineStyle','-.','Color','black')


set(get(get(xl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off')
set(get(get(yl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off')


legend({'w_{1:1}','w_{2:3}','w_{4:5}','w_{6:7}'},'Location','northeastoutside')
legend boxoff



xlim([-1.5 1.5])
ylim([-0.5 0.5])

grid on
axis square
hold off