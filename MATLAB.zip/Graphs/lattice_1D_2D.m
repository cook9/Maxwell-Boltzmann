clear all
close all

D=1;
Q=7;
no=(Q-1)/2;
syms c
lat=sym(zeros(Q,1));
lat(1)=  0*c;
lat(2)=  1*c;
lat(3)= -1*c;
lat(4)=  2*c;
lat(5)= -2*c;
lat(6)=  3*c;
lat(7)= -3*c;

D=2;
new_lat=sym(zeros(Q^2,D));
count=0;
for a=1:Q
for b=1:Q
count=count+1;
new_lat(count,1)=lat(a);
new_lat(count,2)=lat(b);
end
end

chi=double(lat/c);
new_chi=double(new_lat/c);


figure
hold on
set(gcf,'color','white')

sz=10;
subplot(2,2,1)
hold on
title('D1Q7 LATTICE')
xlabel('\chi_{1,\alpha}')
for a=1:Q
quiver(0,0,chi(a),0,0,'Color','black')
end
scatter(0,0,sz,'filled','black')
xlim([-no no])
ylim([-1 1])
grid on
hold off

subplot(2,2,2)
hold on
title('D2Q49 LATTICE')
xlabel('\chi_{1,\alpha}')
ylabel('\chi_{2,\alpha}')
for a=1:Q^D
quiver(0,0,new_chi(a,1),new_chi(a,2),0,'Color','black')
end
xlim([-no no])
ylim([-no no])
grid on
hold off

hold off









































