clear all
close all

D=1;
Q=7;

no=zeros(Q,1);
no(1)=1;
for i=2:Q
no(i)=no(i-1)+1;
end

syms c
lat=sym(zeros(Q,1));
lat(1)=  0*c;
lat(2)=  1*c;
lat(3)= -1*c;
lat(4)=  2*c;
lat(5)= -2*c;
lat(6)=  3*c;
lat(7)= -3*c;

syms c
weight=sym(zeros(Q,1));
weight(1:1)=(36*c^6 - 49*c^4 + 42*c^2 - 15)/(36*c^6);
weight(2:3)=(12*c^4 - 13*c^2 + 5)/(16*c^6);
weight(4:5)=-(3*c^4 - 10*c^2 + 5)/(40*c^6);
weight(6:7)=(4*c^4 - 15*c^2 + 15)/(720*c^6);

fprintf('\n')
fprintf('No.   Xi      Weight Function\n')
for a=1:Q
fprintf('%-5g %-7s %-10s\n',no(a),lat(a),weight(a))
end


fprintf('\n')