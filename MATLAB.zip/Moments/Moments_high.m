clear all
close all
clc

prompt='Number of dimensions: ';
D=input(prompt);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

delta2=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2(i,j,k,l) = delta(i,j)*delta(k,l) + delta(i,k)*delta(j,l) + delta(i,l)*delta(j,k);
end
end
end
end

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

if D==1
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2));
end
if D==2
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2));
end
if D==3
omega=1/((2*pi)^(D/2))*exp(-1/2*(xi(1)^2+xi(2)^2+xi(3)^2));
end

syms rho RT P a b
f=1;
for i=1:D
f=f/sqrt(2*pi*RT)*exp(1/(2*RT)*v(i)^2);
end
f=f*rho;

% HERMITE POLYNOMIALS

h0=1;
h1=sym(zeros(D,1));
h2=sym(zeros(D,D));
h3=sym(zeros(D,D,D));
h4=sym(zeros(D,D,D,D));
h5=sym(zeros(D,D,D,D,D));

a0=1;
a1=sym(zeros(D,1));
a2=sym(zeros(D,D));
a3=sym(zeros(D,D,D));
a4=sym(zeros(D,D,D,D));
a5=sym(zeros(D,D,D,D,D));

for i=1:D
h1(i)=(-1)^1/omega*diff(omega,xi(i));
a1(i)=diff(f,v(i))/f*RT^1;
end

for i=1:D
for j=1:D
h2(i,j)=(-1)^2/omega*diff(diff(omega,xi(i)),xi(j));
a2(i,j)=diff(diff(f,v(i)),v(j))/f*RT^2;
end
end

for i=1:D
for j=1:D
for k=1:D
h3(i,j,k)=(-1)^3/omega*diff(diff(diff(omega,xi(i)),xi(j)),xi(k));
a3(i,j,k)=diff(diff(diff(f,v(i)),v(j)),v(k))/f*RT^3;
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
h4(i,j,k,l)=(-1)^4/omega*diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l));
a4(i,j,k,l)=diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l))/f*RT^4;
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
h5(i,j,k,l,m)=(-1)^5/omega*diff(diff(diff(diff(diff(omega,xi(i)),xi(j)),xi(k)),xi(l)),xi(m));
a5(i,j,k,l,m)=diff(diff(diff(diff(diff(f,v(i)),v(j)),v(k)),v(l)),v(m))/f*RT^5;
end
end
end
end
end

h1=simplify(h1);
h2=simplify(h2);
h3=simplify(h3);
h4=simplify(h4);
h5=simplify(h5);

a1=simplify(a1);
a2=simplify(a2);
a3=simplify(a3);
a4=simplify(a4);
a5=simplify(a5);

























