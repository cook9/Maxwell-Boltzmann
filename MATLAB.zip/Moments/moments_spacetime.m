clear all
close all

D=3;

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

r=sym(zeros(D,1));
syms x y z
if D==1
r(1)=x;
end
if D==2
r(1)=x;r(2)=y;
end
if D==3
r(1)=x;r(2)=y;r(3)=z;
end

syms RT 
syms vr
syms x y z t
cg = [(v1^2 + RT)*vr^2 + (2*v1*RT*t*x + RT^2*t^2)*vr + RT^2*t^2*x^2 (RT*t*x + v1*vr)*(RT*t*y + v2*vr) (RT*t*x + v1*vr)*(RT*t*z + v3*vr); (RT*t*x + v1*vr)*(RT*t*y + v2*vr) (v2^2 + RT)*vr^2 + (2*v2*RT*t*y + RT^2*t^2)*vr + RT^2*t^2*y^2 (RT*t*y + v2*vr)*(RT*t*z + v3*vr); (RT*t*x + v1*vr)*(RT*t*z + v3*vr) (RT*t*y + v2*vr)*(RT*t*z + v3*vr) (v3^2 + RT)*vr^2 + (2*v3*RT*t*z + RT^2*t^2)*vr + RT^2*t^2*z^2;];

mat=sym(zeros(D,D));
for i=1:D
for j=1:D
mat(i,j) = vr^2*(v(i)*v(j)+RT*delta(i,j)) + vr*RT*t*(v(i)*r(j)+v(j)*r(i)) + (RT*t)^2*(r(i)*r(j)+vr*delta(i,j));
end
end

simplify(mat-cg)
























































































































































































































