%clear all
%close all

D=3;

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

if D==1
epsilon=1;
end

if D==2
epsilon=zeros(D,D);
epsilon(1,1) =  0;
epsilon(1,2) =  1;
epsilon(2,1) = -1;
epsilon(2,2) =  0;
end

if D==3
epsilon=zeros(D,D,D);
epsilon(2,3,1) =  1;
epsilon(3,2,1) = -1;
epsilon(1,3,2) = -1;
epsilon(3,1,2) =  1;
epsilon(1,2,3) =  1;
epsilon(2,1,3) = -1;
end

delta2a=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2a(i,j,k,l) = ...
delta(i,k)*delta(j,l) + ...
delta(i,l)*delta(j,k);
end
end
end
end

delta2b=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2b(i,j,k,l) = ...
delta(i,j)*delta(k,l) + ...
delta(i,k)*delta(j,l) + ...
delta(i,l)*delta(j,k);
end
end
end
end

delta3a=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
delta3a(i,j,k,l,m,n) = ...
delta(i,l)*delta2a(k,j,m,n) + ...
delta(i,m)*delta2a(j,k,l,n) + ...
delta(i,n)*delta2a(j,k,l,m);
end
end
end
end
end
end

delta3b=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
delta3b(i,j,k,l,m,n) = ...
delta(i,j)*delta2b(k,l,m,n) + ...
delta(i,k)*delta2b(j,l,m,n) + ...
delta(i,l)*delta2b(k,j,m,n) + ...
delta(i,m)*delta2b(j,k,l,n) + ...
delta(i,n)*delta2b(j,k,l,m);
end
end
end
end
end
end

delta3c=zeros(D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
delta3c(i,j,k,l,m,n) = ...
delta(i,j)*delta2a(k,l,m,n) + ...
delta(i,k)*delta2a(j,l,m,n) + ...
delta(i,l)*delta2a(k,j,m,n) + ...
delta(i,m)*delta2b(j,k,l,n) + ...
delta(i,n)*delta2b(j,k,l,m);
end
end
end
end
end
end

delta4a=zeros(D,D,D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
delta4a(i,j,k,l,m,n,o,p) = ...
delta(i,m)*delta3a(j,k,l,n,o,p) + ...
delta(i,n)*delta3a(j,k,l,m,o,p) + ...
delta(i,o)*delta3a(j,k,l,m,n,p) + ...
delta(i,p)*delta3a(j,k,l,m,n,o);
end
end
end
end
end
end
end
end

delta4b=zeros(D,D,D,D,D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
for n=1:D
for o=1:D
for p=1:D
delta4b(i,j,k,l,m,n,o,p) = ...
delta(i,j)*delta3b(k,l,m,n,o,p) + ...
delta(i,k)*delta3b(j,l,m,n,o,p) + ...
delta(i,l)*delta3b(j,k,m,n,o,p) + ...
delta(i,m)*delta3b(j,k,l,n,o,p) + ...
delta(i,n)*delta3b(j,k,l,m,o,p) + ...
delta(i,o)*delta3b(j,k,l,m,n,p) + ...
delta(i,p)*delta3b(j,k,l,m,n,o);
end
end
end
end
end
end
end
end