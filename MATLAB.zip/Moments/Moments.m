clear all
close all
clc

prompt='Number of dimensions: ';
D=input(prompt);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

delta2=zeros(D,D,D,D);
for i=1:D
for j=1:D
for k=1:D
for l=1:D
delta2(i,j,k,l) = ...
delta(i,j)*delta(k,l) + ...
delta(i,k)*delta(j,l) + ...
delta(i,l)*delta(j,k);
end
end
end
end

syms RT P a b

xi=sym(zeros(D,1));
syms xi1 xi2 xi3
if D==1
xi(1)=xi1;
end
if D==2
xi(1)=xi1;xi(2)=xi2;
end
if D==3
xi(1)=xi1;xi(2)=xi2;xi(3)=xi3;
end

v=sym(zeros(D,1));
syms v1 v2 v3
if D==1
v(1)=v1;
end
if D==2
v(1)=v1;v(2)=v2;
end
if D==3
v(1)=v1;v(2)=v2;v(3)=v3;
end

e0=1;
e1=sym(zeros(D,1));
e2=sym(zeros(D,D));
e3=sym(zeros(D,D,D));
e4=sym(zeros(D,D,D,D));
e5=sym(zeros(D,D,D,D,D));

for i=1:D
e1(i)=v(i);
end

for i=1:D
for j=1:D
e2(i,j)=v(i)*v(j)+RT*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
e3(i,j,k)=v(i)*v(j)*v(k)+RT*(v(i)*delta(j,k)+v(j)*delta(i,k)+v(k)*delta(i,j));
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
e4(i,j,k,l) = v(i)*v(j)*v(k)*v(l) + RT*(...
v(i)*v(j)*delta(k,l) + v(i)*v(k)*delta(j,l) + v(i)*v(l)*delta(j,k)  + ...
v(j)*v(k)*delta(i,l) + v(j)*v(l)*delta(i,k) + v(k)*v(l)*delta(i,j)) + delta2(i,j,k,l)*RT^2;
end
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
for m=1:D
e5(i,j,k,l,m) = v(i)*v(j)*v(k)*v(l)*v(m) + RT*(...
v(i)*v(j)*v(k)*delta(l,m) + v(i)*v(j)*v(l)*delta(k,m) + v(i)*v(k)*v(l)*delta(j,m) + v(j)*v(k)*v(l)*delta(i,m) + v(i)*v(j)*v(m)*delta(k,l) + ...
v(i)*v(k)*v(m)*delta(j,l) + v(j)*v(k)*v(m)*delta(i,l) + v(i)*v(l)*v(m)*delta(j,k) + v(j)*v(l)*v(m)*delta(i,k) + v(k)*v(l)*v(m)*delta(i,j) ) + ...
RT^2*(v(i)*delta2(j,k,l,m) + v(j)*delta2(i,k,l,m) + v(k)*delta2(j,i,l,m) + v(l)*delta2(j,k,i,m) + v(m)*delta2(j,k,l,i)) ;
end
end
end
end
end

e1=simplify(e1);
e2=simplify(e2);
e3=simplify(e3);
e4=simplify(e4);
e5=simplify(e5);

fprintf('Total primary moments:\n')
e0
e1
e2
e3
e4

energy=0;
for i=1:D
energy=energy+e2(i,i);
end

flux1=sym(zeros(D,1));
for i=1:D
for j=1:D
flux1(j)=flux1(j)+e3(i,i,j);
end
end

flux2=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
flux2(j,k)=flux2(j,k)+e4(i,i,j,k);
end
end
end

energy=simplify(energy);
flux1 =simplify(flux1) ;
flux2 =simplify(flux2) ;

fprintf('Partial primary moments:\n')
energy
flux1
flux2

ec0=1;
ec1=sym(zeros(D,1));
ec2=sym(zeros(D,D));
ec3=sym(zeros(D,D,D));
ec4=sym(zeros(D,D,D,D));

for i=1:D
ec1(i)=0;
end

for i=1:D
for j=1:D
ec2(i,j)=RT*delta(i,j);
end
end

for i=1:D
for j=1:D
for k=1:D
ec3(i,j,k)=0;
end
end
end

for i=1:D
for j=1:D
for k=1:D
for l=1:D
ec4(i,j,k,l)=delta2(i,j,k,l)*RT^2;
end
end
end
end

ec1=simplify(ec1);
ec2=simplify(ec2);
ec3=simplify(ec3);
ec4=simplify(ec4);

fprintf('Total central moments:\n')
ec0
ec1
ec2
ec3
ec4

central_energy=0;
for i=1:D
central_energy=central_energy+ec2(i,i);
end

central_flux1=sym(zeros(D,1));
for i=1:D
for j=1:D
central_flux1(j)=central_flux1(j)+ec3(i,i,j);
end
end

central_flux2=sym(zeros(D,D));
for i=1:D
for j=1:D
for k=1:D
central_flux2(j,k)=central_flux2(j,k)+ec4(i,i,j,k);
end
end
end

fprintf('Partial central moments:\n')
central_energy
central_flux1
central_flux2






















