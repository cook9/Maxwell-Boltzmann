clear all
close all

D=2;
Q=37;
lat=zeros(Q,D);
c=1.19697977039307435897239;

for a=1:4
lat(a,1)=c*cos((pi/2)*(a-1));lat(a,2)=c*sin((pi/2)*(a-1));
end
for a=5:8
lat(a,1)=sqrt(2)*c*cos((pi/4)+(pi/2)*(a-5));lat(a,2)=sqrt(2)*c*sin((pi/4)+(pi/2)*(a-5));
end
for a=9:12
lat(a,1)=2*c*cos((pi/2)*(a-1));lat(a,2)=2*c*sin((pi/2)*(a-1));
end
for a=13:16
lat(a,1)=sqrt(2)*2*c*cos((pi/4)+(pi/2)*(a-5));lat(a,2)=sqrt(2)*2*c*sin((pi/4)+(pi/2)*(a-5));
end
for a=17:20
lat(a,1)=3*c*cos((pi/2)*(a-1));lat(a,2)=3*c*sin((pi/2)*(a-1));
end
for a=21:24
lat(a,1)=sqrt(5)*c*cos(atan(1/2)+(pi/2)*(a-21));lat(a,2)=sqrt(5)*c*sin(atan(1/2)+(pi/2)*(a-21));
end
for a=25:28
lat(a,1)=sqrt(5)*c*cos(atan(2/1)+(pi/2)*(a-25));lat(a,2)=sqrt(5)*c*sin(atan(2/1)+(pi/2)*(a-25));
end
for a=29:32
lat(a,1)=sqrt(10)*c*cos(atan(1/3)+(pi/2)*(a-29));lat(a,2)=sqrt(10)*c*sin(atan(1/3)+(pi/2)*(a-29));
end
for a=33:36
lat(a,1)=sqrt(10)*c*cos(atan(3/1)+(pi/2)*(a-33));lat(a,2)=sqrt(10)*c*sin(atan(3/1)+(pi/2)*(a-33));
end

weight=zeros(Q,1);
weight(1:4)   = 0.10730609154221900241246;
weight(5:8)   = 0.05766785988879488203006;
weight(9:12)  = 0.01420821615845075026469;
weight(13:16) = 0.00101193759267357547541;
weight(17:20) = 0.00024530102775771734547;
weight(21:28) = 0.00535304900051377523273;
weight(29:36) = 0.00028341425299419821740;
weight(37)    = 0.23315066913235250228650;

nolat=zeros(Q,1);
nolat(1)=1;
for i=2:Q
nolat(i)=nolat(i-1)+1;
end

tablelat=table(nolat,round(lat(:,1)/c),round(lat(:,2)/c),weight);
tablelat.Properties.VariableNames={'no','lat1/c','lat2/c','weight'}

figure
hold on
set(gcf,'color','white')
title('D2Q37')
xlabel('\xi_{1,\alpha}/c')
ylabel('\xi_{2,\alpha}/c')
for a=1:Q
quiver(0,0,lat(a,1)/c,lat(a,2)/c,0,'Color','blue')
end
xlim([-3 3])
ylim([-3 3])
grid on
hold off