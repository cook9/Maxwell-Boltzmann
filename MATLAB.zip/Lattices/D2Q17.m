clear all
close all

D=2;
Q=17;
lat=zeros(Q,D);
c=sqrt((125+5*sqrt(193))/72);

for a=1:4
lat(a,1)=c*cos((pi/2)*(a-1));
lat(a,2)=c*sin((pi/2)*(a-1));
end

for a=5:8
lat(a,1)=sqrt(2)*c*cos((pi/4)+(pi/2)*(a-1));
lat(a,2)=sqrt(2)*c*sin((pi/4)+(pi/2)*(a-1));
end

for a=9:12
lat(a,1)=sqrt(2)*2*c*cos((pi/4)+(pi/2)*(a-1));
lat(a,2)=sqrt(2)*2*c*sin((pi/4)+(pi/2)*(a-1));
end

for a=13:16
lat(a,1)=3*c*cos((pi/2)*(a-1));
lat(a,2)=3*c*sin((pi/2)*(a-1));
end

weight=zeros(Q,1);
weight(1:4)   = (3355-91*sqrt(193))/18000;
weight(5:8)   = (655+17*sqrt(193))/27000;
weight(9:12)  = (685-49*sqrt(193))/54000;
weight(13:16) = (1445-101*sqrt(193))/162000;
weight(17)    = (575+193*sqrt(193))/8100;

nolat=zeros(Q,1);
nolat(1)=1;
for i=2:Q
nolat(i)=nolat(i-1)+1;
end

tablelat=table(nolat,round(lat(:,1)/c),round(lat(:,2)/c),weight);
tablelat.Properties.VariableNames={'no','lat1/c','lat2/c','weight'}

figure
hold on
set(gcf,'color','white')
title('D2Q17')
xlabel('\xi_{1,\alpha}/c')
ylabel('\xi_{2,\alpha}/c')
for a=1:Q
quiver(0,0,lat(a,1)/c,lat(a,2)/c,0,'Color','blue')
end
xlim([-3 3])
ylim([-3 3])
grid on
hold off