clear all
close all

D=3;
Q=39;
lat=zeros(Q,D);
c=sqrt(3/2);

delta=zeros(D,D);
for i=1:D
delta(i,i)=1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:D
for a=1:3
lat(a,i)=c*delta(i,a);
end
end

for i=1:D
for a=4:6
lat(a,i)=-c*delta(i,a-3);
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for a=7:10
lat(a,1)=sqrt(2)*c*cos((pi/2)*(a-1)+(pi/4));
lat(a,2)=sqrt(2)*c*sin((pi/2)*(a-1)+(pi/4));
lat(a,3)=c;
end

for a=11:14
lat(a,1)=sqrt(2)*c*cos((pi/2)*(a-1)+(pi/4));
lat(a,2)=sqrt(2)*c*sin((pi/2)*(a-1)+(pi/4));
lat(a,3)=-c;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:D
for a=15:17
lat(a,i)=2*c*delta(i,a-14);
end
end

for i=1:D
for a=18:20
lat(a,i)=-2*c*delta(i,a-17);
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for a=21:24
lat(a,1)=2*sqrt(2)*c*cos((pi/2)*(a-1)+(pi/4));
lat(a,2)=2*sqrt(2)*c*sin((pi/2)*(a-1)+(pi/4));
lat(a,3)=0;
end

for a=25:28
lat(a,1)=2*sqrt(2)*c*cos((pi/2)*(a-1)+(pi/4));
lat(a,2)=0;
lat(a,3)=2*sqrt(2)*c*sin((pi/2)*(a-1)+(pi/4));

end

for a=29:32
lat(a,1)=0;
lat(a,2)=2*sqrt(2)*c*cos((pi/2)*(a-1)+(pi/4));
lat(a,3)=2*sqrt(2)*c*sin((pi/2)*(a-1)+(pi/4));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:D
for a=33:35
lat(a,i)=3*c*delta(i,a-32);
end
end

for i=1:D
for a=36:38
lat(a,i)=-3*c*delta(i,a-35);
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a=39;
for i=1:D
lat(a,i)=0;
end

weight=zeros(Q,1);
weight(1:6)=1/12;
weight(7:14)=1/27;
weight(15:20)=2/135;
weight(21:32)=1/432;
weight(33:38)=1/1620;
weight(39)=1/12;

nolat=zeros(Q,1);
nolat(1)=1;
for i=2:Q
nolat(i)=nolat(i-1)+1;
end

tablelat=table(nolat,round(lat(:,1)/c),round(lat(:,2)/c),round(lat(:,3)/c),weight);
tablelat.Properties.VariableNames={'no','lat1/c','lat2/c','lat3/c','weight'}

figure
hold on
set(gcf,'color','white')
title('D3Q39')
xlabel('\xi_{1,\alpha}/c')
ylabel('\xi_{2,\alpha}/c')
zlabel('\xi_{3,\alpha}/c')
for a=1:Q
quiver3(0,0,0,lat(a,1)/c,lat(a,2)/c,lat(a,3)/c,0,'Color','blue')
end
xlim([-3 3])
ylim([-3 3])
zlim([-3 3])
grid on
hold off