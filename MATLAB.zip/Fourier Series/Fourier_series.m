clear all
close all

D=1;
Q=7;

syms c
weight=sym(zeros(Q,1));
weight(1:1)=(36*c^6 - 49*c^4 + 42*c^2 - 15)/(36*c^6);
weight(2:3)=(12*c^4 - 13*c^2 + 5)/(16*c^6);
weight(4:5)=-(3*c^4 - 10*c^2 + 5)/(40*c^6);
weight(6:7)=(4*c^4 - 15*c^2 + 15)/(720*c^6);

count=0;
xi=sym(zeros(Q,1));
for a=2:Q
if rem(a,2)==0
count=count+1;
xi(a)=count*c;
else
xi(a)=-count*c;
end
end

chi=double(xi/c);

syms rho v RT
maxw3=sym(zeros(Q,1));
for a=1:Q
maxw3(a)=weight(a)*rho*(1+xi(a)*v+1/2*((xi(a)^2-1)*(v^2+RT-1))+1/6*((xi(a)^3-3*xi(a))*(v^3+3*v*(RT-1))));
end

sum0=0;
sum1=0;
sum2=0;
for a=1:Q
sum0=sum0+maxw3(a)*xi(a)^0;
sum1=sum1+maxw3(a)*xi(a)^1;
sum2=sum2+maxw3(a)*xi(a)^2;
end

sum0=simplify(sum0);
sum1=simplify(sum1);
sum2=simplify(sum2);

syms x
psitot=sym(zeros(Q,1));
psicos=sym(zeros(Q,1));
psisin=sym(zeros(Q,1));
L1=chi+1/2;
L2=chi-1/2;

nterms=1;
for a=1:Q
term0=maxw3(a)/Q;
term1=0;term2=0;
for n=1:nterms
An=2*maxw3(a)/(n*pi)*sin(n*pi/Q)*(2*(cos(n*pi*chi(a)/Q))^2-1);
term1=term1+An*cos(2*pi*n*x/Q);
Bn=4*maxw3(a)/(n*pi)*sin(n*pi/Q)*sin(n*pi*chi(a)/Q)*cos(n*pi*chi(a)/Q);
term2=term2+Bn*sin(2*pi*n*x/Q);
end
psicos(a)=term0+term1;
psisin(a)=term0+term2;
psitot(a)=term0+term1+term2;
end

psicos=simplify(psicos);
psisin=simplify(psisin);
psitot=simplify(psitot);

psimat=sym(zeros(Q,Q));
for a=1:Q
for b=1:Q
psimat(a,b)=subs(psitot(a),x,chi(b));
end
end

SUM0=0;
SUM1=0;
SUM2=0;
for a=1:Q
for b=1:Q
SUM0=SUM0+psimat(a,b);
SUM1=SUM1+psimat(a,b)*xi(a);
SUM2=SUM2+psimat(a,b)*xi(a)^2;
end
end

SUM0=simplify(SUM0);
SUM1=simplify(SUM1);
SUM2=simplify(SUM2);











































% hasl=25000;
% T0=221.55;
% rho0=0.04008;
% Ru=8.31446261815324;
% Mo=28.013E-3;
% Rs=Ru/Mo;
% v0=20;
% c0=1;
% 
% psitot_num=sym(zeros(Q,1));
% psicos_num=sym(zeros(Q,1));
% psisin_num=sym(zeros(Q,1));
% for a=1:Q
% psitot_num(a)=subs(psitot(a),{rho v RT c},{rho0 v0 Rs*T0 c0});
% psicos_num(a)=subs(psicos(a),{rho v RT c},{rho0 v0 Rs*T0 c0});
% psisin_num(a)=subs(psisin(a),{rho v RT c},{rho0 v0 Rs*T0 c0});
% end
% 
% xi_num=subs(xi,c,c0);
% 
% PSI0=0;
% PSI1=0;
% PSI2=0;
% for a=1:Q
% PSI0=PSI0+psitot_num(a)*xi_num(a)^0;
% PSI1=PSI1+psitot_num(a)*xi_num(a)^1;
% PSI2=PSI2+psitot_num(a)*xi_num(a)^2;
% end
% 
% xp=0;
% SUM0=0;
% SUM1=0;
% SUM2=0;
% for a=1:Q
% SUM0=SUM0+subs(PSI0,x,xp+chi(a));
% SUM1=SUM1+subs(PSI1,x,xp+chi(a));
% SUM2=SUM2+subs(PSI2,x,xp+chi(a));
% end
% 
% SUM0=double(SUM0);
% SUM1=double(SUM1);
% SUM2=double(SUM2);
% 
% newDen=SUM0;
% newVel=SUM1/SUM0;
% newTem=(SUM2/SUM0-newVel^2)/Rs;
% 
% figure
% hold on
% set(gcf,'Color','white')
% 
% subplot(2,2,1)
% hold on
% title('FOURIER COSINE WAVES')
% xlabel('x')
% ylabel('\psi_{\alpha}')
% for a=1:Q
% fplot(psicos_num(a)*10^(-4),'Color','black','LineStyle','-')
% end
% xlim([-Q/2 Q/2])
% grid on
% hold off
% 
% subplot(2,2,2)
% hold on
% title('FOURIER SINE WAVES')
% xlabel('x')
% ylabel('\psi_{\alpha}')
% for a=1:Q
% fplot(psisin_num(a)*10^(-4),'Color','black','LineStyle','-')
% end
% xlim([-Q/2 Q/2])
% grid on
% hold off
% 
% subplot(2,2,3)
% hold on
% title('FOURIER WAVES COMBINED')
% xlabel('x')
% ylabel('\psi_{\alpha}')
% for a=1:Q
% fplot(psitot_num(a)*10^(-4),'Color','black','LineStyle','-')
% end
% xlim([-Q/2 Q/2])
% grid on
% hold off
% 
% subplot(2,2,4)
% hold on
% title('COMBINED WAVE MOMENT 0')
% xlabel('x')
% ylabel('\Psi_{o}')
% fplot(PSI0*10^(-4),'Color','k','LineStyle','-')
% xlim([-Q/2 Q/2])
% grid on
% hold off
% 
% hold off























































































