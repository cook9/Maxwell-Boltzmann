clear all
close all

D=1;
Q=9;

syms dx tau
c=dx/tau;
weight=sym(zeros(Q,1));
weight(1:1) =  (576*c^8 - 820*c^6 + 819*c^4 - 450*c^2 + 105)/(576*c^8);
weight(2:3) =  (192*c^6 - 244*c^4 + 145*c^2 - 35)/(240*c^8);
weight(4:5) = -(48*c^6 - 169*c^4 + 130*c^2 - 35)/(480*c^8);
weight(6:7) =  (64*c^6 - 252*c^4 + 315*c^2 - 105)/(5040*c^8);
weight(8:9) = -(12*c^6 - 49*c^4 + 70*c^2 - 35)/(13440*c^8);

count=0;
xi=sym(zeros(Q,1));
for a=2:Q
if mod(a,2)==0
count=count+1;
xi(a)= count*c;
else
xi(a)=-count*c;
end
end

chi=xi*tau;
step=chi/dx;

syms rho v RT
maxw4=sym(zeros(Q,1));
for a=1:Q
maxw4(a)=weight(a)*rho*(((xi(a)^2 - 1)*(v^2 + RT - 1))/2 + v*xi(a) + ((xi(a)^4 - 6*xi(a)^2 + 3)*(3*(RT - 1)^2 + v^4 + 6*v^2*(RT - 1)))/24 - ((- xi(a)^3 + 3*xi(a))*(3*v*(RT - 1) + v^3))/6 + 1);
end

sum0=0;
sum1=0;
sum2=0;
for a=1:Q
sum0=sum0+maxw4(a)*xi(a)^0;
sum1=sum1+maxw4(a)*xi(a)^1;
sum2=sum2+maxw4(a)*xi(a)^2;
end

sum0=simplify(sum0);
sum1=simplify(sum1);
sum2=simplify(sum2);

syms x
psi=sym(zeros(Q,1));
L1=dx*(step+1/2);
L2=dx*(step-1/2);

nterms=1;
for a=1:Q
term0=maxw4(a)/Q;
term1=0;
term2=0;
for n=1:nterms
An=2*maxw4(a)/(n*pi)*sin(n*pi/Q)*cos(2*pi*n*step(a)/Q);
Bn=4*maxw4(a)/(n*pi)*sin(n*pi/Q)*sin(n*pi*step(a)/Q)*cos(n*pi*step(a)/Q);
term1=term1+An*cos(2*pi*n*x/(Q*dx));
term2=term2+Bn*sin(2*pi*n*x/(Q*dx));
end
psi(a)=term0+term1+term2;
end

psi=simplify(psi);

psimat=sym(zeros(Q,Q));
for a=1:Q
for b=1:Q
psimat(a,b)=subs(psi(a),x,chi(b));
end
end

SUM0=0;
SUM1=0;
SUM2=0;
for a=1:Q
for b=1:Q
SUM0=SUM0+psimat(a,b);
SUM1=SUM1+psimat(a,b)*xi(a);
SUM2=SUM2+psimat(a,b)*xi(a)^2;
end
end

SUM0=simplify(SUM0);
SUM1=simplify(SUM1);
SUM2=simplify(SUM2);























































































































